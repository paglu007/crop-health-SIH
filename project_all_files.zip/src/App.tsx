import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { AdvisoryTester } from './components/AdvisoryTester';
import { DatasetExplorer } from './components/DatasetExplorer';
import { AgenticToolViewer } from './components/AgenticToolViewer';
import { BackendCodeExplorer } from './components/BackendCodeExplorer';
import { ActiveTab, DiseaseRecord } from './types';
import { Leaf, ShieldAlert, CheckCircle2 } from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState<ActiveTab>('tester');
  const [records, setRecords] = useState<DiseaseRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedCrop, setSelectedCrop] = useState('Tomato');
  const [selectedDisease, setSelectedDisease] = useState('Early Blight');

  useEffect(() => {
    async function fetchDataset() {
      try {
        const res = await fetch('/api/diseases');
        if (res.ok) {
          const data: DiseaseRecord[] = await res.json();
          setRecords(data);
        }
      } catch (err) {
        console.error('Failed to load dataset from /api/diseases', err);
      } finally {
        setLoading(false);
      }
    }
    fetchDataset();
  }, []);

  const handleSelectForTesting = (crop: string, disease: string) => {
    setSelectedCrop(crop);
    setSelectedDisease(disease);
    setActiveTab('tester');
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-emerald-500/30 selection:text-emerald-200">
      {/* Top Navigation */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        recordCount={records.length}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8">
        {loading ? (
          <div className="flex flex-col items-center justify-center py-24 space-y-4">
            <div className="w-10 h-10 border-4 border-emerald-500 border-t-transparent rounded-full animate-spin" />
            <p className="text-sm text-slate-400 font-medium">
              Loading 143 crop disease advisory records from backend...
            </p>
          </div>
        ) : (
          <>
            {activeTab === 'tester' && (
              <AdvisoryTester
                records={records}
                initialCrop={selectedCrop}
                initialDisease={selectedDisease}
              />
            )}

            {activeTab === 'dataset' && (
              <DatasetExplorer
                records={records}
                onSelectForTesting={handleSelectForTesting}
              />
            )}

            {activeTab === 'agentic-tool' && <AgenticToolViewer />}

            {activeTab === 'java-architecture' && <BackendCodeExplorer />}
          </>
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-slate-800/80 bg-slate-900/50 py-6 text-xs text-slate-400 mt-auto">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center space-x-2">
            <Leaf className="w-4 h-4 text-emerald-400" />
            <span className="font-semibold text-slate-200">
              Crop Disease Risk Advisory System
            </span>
            <span className="text-slate-600">&bull;</span>
            <span>Smart India Hackathon (SIH 2026)</span>
          </div>

          <div className="flex items-center space-x-4 text-slate-400">
            <span>
              Risk formula: <strong className="text-slate-200 font-mono">0.6&times;CV + 0.4&times;Weather</strong>
            </span>
            <span className="text-slate-600">&bull;</span>
            <span className="text-emerald-400 font-mono">Spring Boot Backend Ready</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
