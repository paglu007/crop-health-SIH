export interface DiseaseRecord {
  diseaseId: number;
  crop: string;
  diseaseName: string;
  pathogenType: string;
  symptoms: string;
  favorableConditions: string;
  lowRiskAdvisory: string;
  mediumRiskAdvisory: string;
  highRiskAdvisory: string;
  expertAdvisory: string;
  preventiveMeasures: string;
  organicTreatment: string;
  chemicalTreatment: string;
}

export type RiskLevel = 'LOW' | 'MEDIUM' | 'HIGH';

export interface AdvisoryRequestPayload {
  crop: string;
  diseaseName: string;
  cvConfidence: number;
  weatherRiskScore: number;
}

export interface AdvisoryResponsePayload {
  crop: string;
  diseaseName: string;
  pathogenType: string;
  symptoms: string;
  favorableConditions: string;
  riskLevel: RiskLevel;
  finalRiskScore: number;
  riskAdvisory: string;
  preventiveMeasures: string;
  organicTreatment: string;
  chemicalTreatment: string;
  expertAdvisory: string;
  recordFound: boolean;
}

export type ActiveTab = 'tester' | 'dataset' | 'agentic-tool' | 'java-architecture';
