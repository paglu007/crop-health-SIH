import React from 'react';
import { Leaf, Activity, Database, Bot, Code2, CheckCircle2 } from 'lucide-react';
import { ActiveTab } from '../types';

interface NavbarProps {
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  recordCount: number;
}

export const Navbar: React.FC<NavbarProps> = ({ activeTab, setActiveTab, recordCount }) => {
  const tabs = [
    { id: 'tester' as ActiveTab, label: 'Risk Advisory API Tester', icon: Activity },
    { id: 'dataset' as ActiveTab, label: `143 Disease Dataset (${recordCount})`, icon: Database },
    { id: 'agentic-tool' as ActiveTab, label: 'Agentic AI Tool & Guardrails', icon: Bot },
    { id: 'java-architecture' as ActiveTab, label: 'Spring Boot Backend Code', icon: Code2 },
  ];

  return (
    <header className="sticky top-0 z-50 bg-slate-900 border-b border-slate-800 shadow-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Brand & SIH Badge */}
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
              <Leaf className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <span className="font-bold text-slate-100 text-base sm:text-lg tracking-tight">
                  Crop Disease Risk Advisory
                </span>
                <span className="px-2 py-0.5 text-xs font-semibold uppercase tracking-wider rounded-full bg-emerald-950 text-emerald-300 border border-emerald-800/80">
                  SIH 2026
                </span>
              </div>
              <p className="text-xs text-slate-400 hidden sm:block">
                Spring Boot Backend &middot; Formula: 0.6&times;CV + 0.4&times;Weather &middot; 143 Dataset Records
              </p>
            </div>
          </div>

          {/* Backend Status indicator */}
          <div className="flex items-center space-x-2 px-3 py-1 rounded-full bg-slate-800/80 border border-slate-700/60 text-xs text-slate-300">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
            <span className="font-mono text-emerald-400 font-semibold">POST /api/advisory</span>
            <span className="text-slate-500">|</span>
            <span className="text-slate-400">H2 In-Memory DB</span>
          </div>
        </div>

        {/* Tab Navigation */}
        <nav className="flex space-x-1 sm:space-x-2 overflow-x-auto py-2 border-t border-slate-800/80 scrollbar-none">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                id={`tab-btn-${tab.id}`}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center space-x-2 px-3.5 py-2 rounded-lg text-xs sm:text-sm font-medium transition-all whitespace-nowrap ${
                  isActive
                    ? 'bg-emerald-500/15 text-emerald-300 border border-emerald-500/30 shadow-sm'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50 border border-transparent'
                }`}
              >
                <Icon className={`w-4 h-4 ${isActive ? 'text-emerald-400' : 'text-slate-400'}`} />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </nav>
      </div>
    </header>
  );
};
