import React, { useState, useEffect } from 'react';
import {
  Send,
  Sparkles,
  AlertTriangle,
  ShieldCheck,
  Info,
  Thermometer,
  Eye,
  Copy,
  Check,
  CornerDownRight,
  Stethoscope,
  FlaskConical,
  Sprout,
  ShieldAlert,
  Leaf,
} from 'lucide-react';
import { AdvisoryResponsePayload, DiseaseRecord } from '../types';

interface AdvisoryTesterProps {
  records: DiseaseRecord[];
  initialCrop?: string;
  initialDisease?: string;
}

const POPULAR_CROPS = [
  'Tomato',
  'Wheat',
  'Rice',
  'Cotton',
  'Potato',
  'Sugarcane',
  'Maize',
  'Groundnut',
  'Soybean',
  'Apple',
  'Banana',
  'Coffee',
];

export const AdvisoryTester: React.FC<AdvisoryTesterProps> = ({
  records,
  initialCrop = 'Tomato',
  initialDisease = 'Early Blight',
}) => {
  const [crop, setCrop] = useState(initialCrop);
  const [diseaseName, setDiseaseName] = useState(initialDisease);
  const [cvConfidence, setCvConfidence] = useState(0.82);
  const [weatherRiskScore, setWeatherRiskScore] = useState(0.75);
  const [loading, setLoading] = useState(false);
  const [response, setResponse] = useState<AdvisoryResponsePayload | null>(null);
  const [copiedJson, setCopiedJson] = useState(false);
  const [copiedCurl, setCopiedCurl] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  // Suggested diseases for the currently chosen crop
  const availableDiseasesForCrop = records
    .filter((r) => r.crop.toLowerCase() === crop.trim().toLowerCase())
    .map((r) => r.diseaseName);

  // Live client-side preview of math
  const calculatedRawScore = 0.6 * cvConfidence + 0.4 * weatherRiskScore;
  const previewScore = Number(calculatedRawScore.toFixed(4));
  const previewLevel =
    previewScore < 0.4 ? 'LOW' : previewScore <= 0.7 ? 'MEDIUM' : 'HIGH';

  // Trigger advisory computation
  const handleCalculate = async (
    targetCrop = crop,
    targetDisease = diseaseName,
    cv = cvConfidence,
    weather = weatherRiskScore
  ) => {
    setLoading(true);
    setErrorMsg(null);
    try {
      const res = await fetch('/api/advisory', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          crop: targetCrop,
          diseaseName: targetDisease,
          cvConfidence: cv,
          weatherRiskScore: weather,
        }),
      });

      if (!res.ok) {
        const errorData = await res.json().catch(() => ({ error: 'Request failed' }));
        throw new Error(errorData.error || `HTTP error ${res.status}`);
      }

      const data: AdvisoryResponsePayload = await res.json();
      setResponse(data);
    } catch (err: any) {
      console.error(err);
      setErrorMsg(err.message || 'Error communicating with /api/advisory endpoint');
    } finally {
      setLoading(false);
    }
  };

  // Initial load
  useEffect(() => {
    handleCalculate(crop, diseaseName, cvConfidence, weatherRiskScore);
  }, []);

  const handleCopyJson = () => {
    if (!response) return;
    navigator.clipboard.writeText(JSON.stringify(response, null, 2));
    setCopiedJson(true);
    setTimeout(() => setCopiedJson(false), 2000);
  };

  const handleCopyCurl = () => {
    const curl = `curl -X POST http://localhost:3000/api/advisory \\\n  -H "Content-Type: application/json" \\\n  -d '{\n    "crop": "${crop}",\n    "diseaseName": "${diseaseName}",\n    "cvConfidence": ${cvConfidence},\n    "weatherRiskScore": ${weatherRiskScore}\n  }'`;
    navigator.clipboard.writeText(curl);
    setCopiedCurl(true);
    setTimeout(() => setCopiedCurl(false), 2000);
  };

  const triggerFallbackTest = () => {
    setCrop('Avocado');
    setDiseaseName('Unregistered Mildew');
    setCvConfidence(0.5);
    setWeatherRiskScore(0.5);
    handleCalculate('Avocado', 'Unregistered Mildew', 0.5, 0.5);
  };

  const getRiskBadgeColor = (level: string) => {
    switch (level) {
      case 'HIGH':
        return 'bg-red-500/15 text-red-400 border-red-500/30';
      case 'MEDIUM':
        return 'bg-amber-500/15 text-amber-300 border-amber-500/30';
      case 'LOW':
      default:
        return 'bg-emerald-500/15 text-emerald-300 border-emerald-500/30';
    }
  };

  return (
    <div className="space-y-6">
      {/* Intro Banner */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-5 sm:p-6 shadow-sm">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h2 className="text-xl sm:text-2xl font-bold text-slate-100 flex items-center gap-2.5">
              <Sparkles className="w-6 h-6 text-emerald-400" />
              Live Crop Disease Risk Advisory Engine
            </h2>
            <p className="text-sm text-slate-400 mt-1 max-w-3xl">
              Implements SIH 2026 specifications: <code className="text-emerald-400">POST /api/advisory</code> with formula{' '}
              <span className="font-semibold text-slate-200">finalRisk = 0.6&times;cvConfidence + 0.4&times;weatherRiskScore</span>.
              Returns all 12 agronomic and treatment fields, selected risk advisory text, and expert consultation prompts.
            </p>
          </div>
          <div className="flex items-center gap-2">
            <button
              id="test-fallback-btn"
              onClick={triggerFallbackTest}
              className="px-3 py-1.5 rounded-lg text-xs font-medium bg-slate-800 hover:bg-slate-700 text-amber-300 border border-amber-500/30 transition-colors flex items-center gap-1.5"
            >
              <AlertTriangle className="w-3.5 h-3.5" />
              Test Fallback Mode
            </button>
          </div>
        </div>
      </div>

      {/* Main Grid: Inputs on Left, Response on Right */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Form Controls */}
        <div className="lg:col-span-5 space-y-5">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 sm:p-6 space-y-5 shadow-sm">
            <h3 className="text-base font-semibold text-slate-200 flex items-center justify-between border-b border-slate-800 pb-3">
              <span>Input Parameters</span>
              <span className="text-xs font-normal text-slate-400 font-mono">POST Payload</span>
            </h3>

            {/* Quick Crop Chips */}
            <div>
              <label className="block text-xs font-medium text-slate-400 mb-2">
                Quick Select Crop
              </label>
              <div className="flex flex-wrap gap-1.5">
                {POPULAR_CROPS.map((c) => (
                  <button
                    key={c}
                    type="button"
                    onClick={() => {
                      setCrop(c);
                      const matched = records.filter(
                        (r) => r.crop.toLowerCase() === c.toLowerCase()
                      );
                      if (matched.length > 0) {
                        setDiseaseName(matched[0].diseaseName);
                      }
                    }}
                    className={`px-2.5 py-1 rounded-md text-xs transition-all ${
                      crop.toLowerCase() === c.toLowerCase()
                        ? 'bg-emerald-500 text-slate-950 font-semibold shadow-sm'
                        : 'bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-750'
                    }`}
                  >
                    {c}
                  </button>
                ))}
              </div>
            </div>

            {/* Crop Field */}
            <div>
              <label htmlFor="crop-input" className="block text-xs font-medium text-slate-300 mb-1">
                Crop Name (<code className="text-emerald-400">crop</code>)
              </label>
              <input
                id="crop-input"
                type="text"
                value={crop}
                onChange={(e) => setCrop(e.target.value)}
                placeholder="e.g. Tomato, Wheat, Rice"
                className="w-full px-3.5 py-2 rounded-xl bg-slate-950 border border-slate-700 text-slate-100 text-sm focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500"
              />
            </div>

            {/* Disease Name Field */}
            <div>
              <label htmlFor="disease-input" className="block text-xs font-medium text-slate-300 mb-1">
                Disease Name (<code className="text-emerald-400">diseaseName</code>)
              </label>
              <input
                id="disease-input"
                type="text"
                value={diseaseName}
                onChange={(e) => setDiseaseName(e.target.value)}
                placeholder="e.g. Early Blight, Leaf Rust, Blast"
                className="w-full px-3.5 py-2 rounded-xl bg-slate-950 border border-slate-700 text-slate-100 text-sm focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500"
              />
              {availableDiseasesForCrop.length > 0 && (
                <div className="mt-2">
                  <span className="text-[11px] text-slate-500 block mb-1">
                    Known diseases for {crop}:
                  </span>
                  <div className="flex flex-wrap gap-1">
                    {availableDiseasesForCrop.map((d) => (
                      <button
                        key={d}
                        type="button"
                        onClick={() => setDiseaseName(d)}
                        className={`text-[11px] px-2 py-0.5 rounded border transition-colors ${
                          diseaseName.toLowerCase() === d.toLowerCase()
                            ? 'bg-emerald-950 text-emerald-300 border-emerald-700 font-medium'
                            : 'bg-slate-800 text-slate-400 border-slate-700 hover:text-slate-200'
                        }`}
                      >
                        {d}
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* CV Model Confidence Slider */}
            <div className="space-y-2 pt-2 border-t border-slate-800">
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-300 font-medium flex items-center gap-1.5">
                  <Eye className="w-3.5 h-3.5 text-sky-400" />
                  CV Model Confidence (<code className="text-sky-400">cvConfidence</code>)
                </span>
                <span className="font-mono font-bold text-sky-400 text-sm bg-sky-950/60 px-2 py-0.5 rounded border border-sky-800/60">
                  {cvConfidence.toFixed(2)}
                </span>
              </div>
              <input
                id="cv-confidence-slider"
                type="range"
                min="0"
                max="1"
                step="0.01"
                value={cvConfidence}
                onChange={(e) => setCvConfidence(parseFloat(e.target.value))}
                className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-sky-500"
              />
              <div className="flex justify-between text-[11px] text-slate-500">
                <span>0.0 (Uncertain)</span>
                <span>Weight: 60%</span>
                <span>1.0 (Certain)</span>
              </div>
            </div>

            {/* Weather Risk Score Slider */}
            <div className="space-y-2 pt-2 border-t border-slate-800">
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-300 font-medium flex items-center gap-1.5">
                  <Thermometer className="w-3.5 h-3.5 text-amber-400" />
                  Weather Risk Score (<code className="text-amber-400">weatherRiskScore</code>)
                </span>
                <span className="font-mono font-bold text-amber-400 text-sm bg-amber-950/60 px-2 py-0.5 rounded border border-amber-800/60">
                  {weatherRiskScore.toFixed(2)}
                </span>
              </div>
              <input
                id="weather-risk-slider"
                type="range"
                min="0"
                max="1"
                step="0.01"
                value={weatherRiskScore}
                onChange={(e) => setWeatherRiskScore(parseFloat(e.target.value))}
                className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-amber-500"
              />
              <div className="flex justify-between text-[11px] text-slate-500">
                <span>0.0 (Dry/Unfavorable)</span>
                <span>Weight: 40%</span>
                <span>1.0 (Optimal humidity/temp)</span>
              </div>
            </div>

            {/* Real-time Math Preview */}
            <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 space-y-2 text-xs font-mono">
              <div className="text-slate-400 flex items-center justify-between">
                <span>Computed Composite Score:</span>
                <span className={`px-2 py-0.5 rounded font-bold border ${getRiskBadgeColor(previewLevel)}`}>
                  {previewLevel}
                </span>
              </div>
              <div className="text-slate-200 text-sm font-semibold flex items-center justify-between">
                <span>0.6 &times; {cvConfidence.toFixed(2)} + 0.4 &times; {weatherRiskScore.toFixed(2)} =</span>
                <span className="text-emerald-400 text-base">{previewScore}</span>
              </div>
            </div>

            {/* Submit Button */}
            <button
              id="submit-advisory-btn"
              type="button"
              disabled={loading}
              onClick={() => handleCalculate()}
              className="w-full py-2.5 px-4 rounded-xl bg-emerald-500 hover:bg-emerald-400 active:bg-emerald-600 text-slate-950 font-bold text-sm transition-all shadow-md flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
            >
              {loading ? (
                <>
                  <div className="w-4 h-4 border-2 border-slate-950 border-t-transparent rounded-full animate-spin" />
                  <span>Processing Advisory...</span>
                </>
              ) : (
                <>
                  <Send className="w-4 h-4" />
                  <span>Execute POST /api/advisory</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Right Column: Advisory Output */}
        <div className="lg:col-span-7 space-y-5">
          {errorMsg && (
            <div className="p-4 rounded-xl bg-red-950/40 border border-red-800/80 text-red-300 text-sm flex items-start gap-3">
              <AlertTriangle className="w-5 h-5 text-red-400 shrink-0 mt-0.5" />
              <div>
                <h4 className="font-semibold text-red-200">API Error</h4>
                <p className="text-xs text-red-300 mt-0.5">{errorMsg}</p>
              </div>
            </div>
          )}

          {response ? (
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 sm:p-6 space-y-6 shadow-sm">
              {/* Header Bar */}
              <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-800 pb-4">
                <div>
                  <div className="flex items-center gap-2.5">
                    <span className="text-xs text-slate-400 font-mono">Response Payload</span>
                    <span
                      className={`text-xs px-2.5 py-0.5 rounded-full font-medium border flex items-center gap-1.5 ${
                        response.recordFound
                          ? 'bg-emerald-950/60 text-emerald-300 border-emerald-800/60'
                          : 'bg-amber-950/60 text-amber-300 border-amber-800/60'
                      }`}
                    >
                      {response.recordFound ? (
                        <>
                          <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                          Matched Record in Database
                        </>
                      ) : (
                        <>
                          <AlertTriangle className="w-3.5 h-3.5 text-amber-400" />
                          Graceful Fallback Mode (Unrecorded)
                        </>
                      )}
                    </span>
                  </div>
                  <h3 className="text-xl font-bold text-slate-100 mt-1">
                    {response.crop} &mdash; {response.diseaseName}
                  </h3>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    id="copy-json-btn"
                    onClick={handleCopyJson}
                    className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs border border-slate-700 flex items-center gap-1.5 transition-colors"
                    title="Copy response JSON"
                  >
                    {copiedJson ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                    <span className="hidden sm:inline">JSON</span>
                  </button>
                  <button
                    id="copy-curl-btn"
                    onClick={handleCopyCurl}
                    className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs border border-slate-700 flex items-center gap-1.5 transition-colors"
                    title="Copy cURL command"
                  >
                    {copiedCurl ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <CornerDownRight className="w-3.5 h-3.5" />}
                    <span className="hidden sm:inline">cURL</span>
                  </button>
                </div>
              </div>

              {/* Metric Highlights */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800">
                  <span className="text-[11px] font-medium text-slate-400 uppercase tracking-wider block">
                    Assigned Risk Tier
                  </span>
                  <div className="mt-1 flex items-center gap-2">
                    <span className={`px-2.5 py-0.5 rounded-md text-sm font-bold border ${getRiskBadgeColor(response.riskLevel)}`}>
                      {response.riskLevel} RISK
                    </span>
                  </div>
                </div>

                <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800">
                  <span className="text-[11px] font-medium text-slate-400 uppercase tracking-wider block">
                    Composite Score
                  </span>
                  <div className="mt-1 flex items-baseline gap-1.5">
                    <span className="text-xl font-bold font-mono text-emerald-400">
                      {response.finalRiskScore.toFixed(4)}
                    </span>
                    <span className="text-xs text-slate-500">/ 1.0000</span>
                  </div>
                </div>

                <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800">
                  <span className="text-[11px] font-medium text-slate-400 uppercase tracking-wider block">
                    Pathogen Type
                  </span>
                  <div className="mt-1">
                    <span className="inline-block px-2 py-0.5 rounded text-xs font-mono bg-slate-800 text-slate-200 border border-slate-700">
                      {response.pathogenType}
                    </span>
                  </div>
                </div>
              </div>

              {/* Dynamic Risk Advisory (Key matching text) */}
              <div className="p-4 rounded-xl bg-gradient-to-r from-slate-950 to-slate-900 border-l-4 border-l-emerald-500 border border-slate-800 space-y-1.5">
                <span className="text-xs font-semibold uppercase tracking-wider text-emerald-400 flex items-center gap-1.5">
                  <ShieldCheck className="w-4 h-4" />
                  Active {response.riskLevel} Risk Advisory Recommendation
                </span>
                <p className="text-sm text-slate-200 leading-relaxed font-normal">
                  {response.riskAdvisory}
                </p>
              </div>

              {/* Symptoms & Favorable Conditions */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="p-4 rounded-xl bg-slate-950/60 border border-slate-800 space-y-1.5">
                  <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
                    <Stethoscope className="w-3.5 h-3.5 text-amber-400" />
                    Observed Symptoms
                  </h4>
                  <p className="text-xs text-slate-300 leading-relaxed">
                    {response.symptoms}
                  </p>
                </div>

                <div className="p-4 rounded-xl bg-slate-950/60 border border-slate-800 space-y-1.5">
                  <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
                    <Thermometer className="w-3.5 h-3.5 text-sky-400" />
                    Favorable Environmental Conditions
                  </h4>
                  <p className="text-xs text-slate-300 leading-relaxed">
                    {response.favorableConditions}
                  </p>
                </div>
              </div>

              {/* Actionable Measures: Prevention, Organic, Chemical */}
              <div className="space-y-3">
                <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider">
                  Management Protocols
                </h4>

                {/* Preventive Measures */}
                <div className="p-3.5 rounded-xl bg-slate-950/40 border border-slate-800 flex items-start gap-3">
                  <Sprout className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                  <div>
                    <span className="text-xs font-semibold text-emerald-300">Preventive Measures:</span>
                    <p className="text-xs text-slate-300 mt-0.5 leading-relaxed">
                      {response.preventiveMeasures}
                    </p>
                  </div>
                </div>

                {/* Organic Treatment */}
                <div className="p-3.5 rounded-xl bg-slate-950/40 border border-slate-800 flex items-start gap-3">
                  <Leaf className="w-4 h-4 text-teal-400 shrink-0 mt-0.5" />
                  <div>
                    <span className="text-xs font-semibold text-teal-300">Organic & Bio-Control:</span>
                    <p className="text-xs text-slate-300 mt-0.5 leading-relaxed">
                      {response.organicTreatment}
                    </p>
                  </div>
                </div>

                {/* Chemical Treatment */}
                <div className="p-3.5 rounded-xl bg-slate-950/40 border border-slate-800 flex items-start gap-3">
                  <FlaskConical className="w-4 h-4 text-indigo-400 shrink-0 mt-0.5" />
                  <div>
                    <span className="text-xs font-semibold text-indigo-300">Chemical Treatment Class:</span>
                    <p className="text-xs text-slate-300 mt-0.5 leading-relaxed">
                      {response.chemicalTreatment}
                    </p>
                  </div>
                </div>
              </div>

              {/* Mandatory Expert Advisory Notice */}
              <div className="p-4 rounded-xl bg-amber-950/20 border border-amber-800/40 flex items-start gap-3">
                <ShieldAlert className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
                <div className="space-y-1">
                  <span className="text-xs font-bold text-amber-300 uppercase tracking-wider">
                    Expert Advisory & Escalation Protocol (Always Included)
                  </span>
                  <p className="text-xs text-amber-200/90 leading-relaxed">
                    {response.expertAdvisory}
                  </p>
                </div>
              </div>
            </div>
          ) : (
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-12 text-center text-slate-500">
              <Info className="w-8 h-8 mx-auto text-slate-600 mb-2" />
              <p className="text-sm">Click "Execute POST /api/advisory" to compute risk and retrieve advisory.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
