import React, { useState, useMemo } from 'react';
import {
  Search,
  Filter,
  ArrowUpDown,
  ExternalLink,
  Layers,
  Sparkles,
  X,
  ChevronRight,
  Stethoscope,
  Thermometer,
  Shield,
  Leaf,
  FlaskConical,
} from 'lucide-react';
import { DiseaseRecord } from '../types';

interface DatasetExplorerProps {
  records: DiseaseRecord[];
  onSelectForTesting: (crop: string, disease: string) => void;
}

const PATHOGEN_TYPES = [
  'ALL',
  'fungal_blight',
  'fungal_rust',
  'fungal_smut',
  'bacterial',
  'viral',
  'nematode',
  'phytoplasma',
  'nutrient_disorder',
];

export const DatasetExplorer: React.FC<DatasetExplorerProps> = ({
  records,
  onSelectForTesting,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedPathogen, setSelectedPathogen] = useState('ALL');
  const [selectedCrop, setSelectedCrop] = useState('ALL');
  const [activeModalRecord, setActiveModalRecord] = useState<DiseaseRecord | null>(null);

  // Extract distinct crops
  const distinctCrops = useMemo(() => {
    const set = new Set(records.map((r) => r.crop));
    return ['ALL', ...Array.from(set).sort()];
  }, [records]);

  // Filtered dataset
  const filteredRecords = useMemo(() => {
    return records.filter((item) => {
      const matchesSearch =
        searchTerm === '' ||
        item.crop.toLowerCase().includes(searchTerm.toLowerCase()) ||
        item.diseaseName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        item.symptoms.toLowerCase().includes(searchTerm.toLowerCase()) ||
        item.pathogenType.toLowerCase().includes(searchTerm.toLowerCase());

      const matchesPathogen =
        selectedPathogen === 'ALL' || item.pathogenType === selectedPathogen;

      const matchesCrop =
        selectedCrop === 'ALL' || item.crop === selectedCrop;

      return matchesSearch && matchesPathogen && matchesCrop;
    });
  }, [records, searchTerm, selectedPathogen, selectedCrop]);

  const getPathogenColor = (type: string) => {
    switch (type) {
      case 'fungal_blight':
        return 'bg-amber-950/80 text-amber-300 border-amber-800/80';
      case 'fungal_rust':
        return 'bg-orange-950/80 text-orange-300 border-orange-800/80';
      case 'fungal_smut':
        return 'bg-stone-900 text-stone-300 border-stone-700';
      case 'bacterial':
        return 'bg-rose-950/80 text-rose-300 border-rose-800/80';
      case 'viral':
        return 'bg-purple-950/80 text-purple-300 border-purple-800/80';
      case 'nematode':
        return 'bg-emerald-950/80 text-emerald-300 border-emerald-800/80';
      case 'phytoplasma':
        return 'bg-cyan-950/80 text-cyan-300 border-cyan-800/80';
      case 'nutrient_disorder':
        return 'bg-yellow-950/80 text-yellow-300 border-yellow-800/80';
      default:
        return 'bg-slate-800 text-slate-300 border-slate-700';
    }
  };

  return (
    <div className="space-y-6">
      {/* Header & Stats Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 sm:p-6 shadow-sm">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-950 text-emerald-300 border border-emerald-800/80">
                143 Total Records Verified
              </span>
              <span className="text-xs text-slate-400 font-mono">plant_disease_advisory_dataset.csv</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-bold text-slate-100 mt-2">
              Comprehensive Agronomic Advisory Knowledge Base
            </h2>
            <p className="text-xs sm:text-sm text-slate-400 mt-1 max-w-2xl">
              Each entry maps 13 standardized columns loaded into Spring Boot H2 database via Apache Commons CSV parser.
            </p>
          </div>
          <div className="text-right hidden sm:block">
            <span className="text-xs text-slate-400">Displaying</span>
            <div className="text-2xl font-bold text-emerald-400 font-mono">
              {filteredRecords.length} / {records.length}
            </div>
          </div>
        </div>
      </div>

      {/* Filter Toolbar */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 sm:p-5 space-y-4">
        <div className="grid grid-cols-1 sm:grid-cols-12 gap-3">
          {/* Search Input */}
          <div className="sm:col-span-6 relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search by crop, disease name, symptoms..."
              className="w-full pl-9 pr-3.5 py-2 rounded-xl bg-slate-950 border border-slate-700 text-slate-200 text-xs sm:text-sm focus:outline-none focus:border-emerald-500"
            />
            {searchTerm && (
              <button
                onClick={() => setSearchTerm('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-200"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {/* Crop Selector */}
          <div className="sm:col-span-3">
            <select
              value={selectedCrop}
              onChange={(e) => setSelectedCrop(e.target.value)}
              className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-slate-200 text-xs sm:text-sm focus:outline-none focus:border-emerald-500"
            >
              {distinctCrops.map((c) => (
                <option key={c} value={c}>
                  {c === 'ALL' ? 'All Crops (143)' : c}
                </option>
              ))}
            </select>
          </div>

          {/* Pathogen Type Selector */}
          <div className="sm:col-span-3">
            <select
              value={selectedPathogen}
              onChange={(e) => setSelectedPathogen(e.target.value)}
              className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-slate-200 text-xs sm:text-sm focus:outline-none focus:border-emerald-500"
            >
              {PATHOGEN_TYPES.map((p) => (
                <option key={p} value={p}>
                  {p === 'ALL' ? 'All Pathogen Types' : p}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Pathogen Quick Chips */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none text-xs">
          <span className="text-slate-500 text-[11px] uppercase tracking-wider shrink-0 mr-1">
            Filter:
          </span>
          {PATHOGEN_TYPES.map((p) => (
            <button
              key={p}
              onClick={() => setSelectedPathogen(p)}
              className={`px-2.5 py-1 rounded-lg text-xs font-mono whitespace-nowrap transition-all ${
                selectedPathogen === p
                  ? 'bg-emerald-500 text-slate-950 font-bold shadow-sm'
                  : 'bg-slate-800 text-slate-400 hover:text-slate-200 hover:bg-slate-700/80 border border-slate-750'
              }`}
            >
              {p}
            </button>
          ))}
        </div>
      </div>

      {/* Dataset Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredRecords.map((item) => (
          <div
            key={item.diseaseId}
            className="bg-slate-900 border border-slate-800 hover:border-slate-700 rounded-2xl p-4 sm:p-5 flex flex-col justify-between transition-all hover:shadow-md group"
          >
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold px-2 py-0.5 rounded bg-slate-800 text-slate-300">
                  {item.crop}
                </span>
                <span
                  className={`text-[11px] font-mono px-2 py-0.5 rounded border ${getPathogenColor(
                    item.pathogenType
                  )}`}
                >
                  {item.pathogenType}
                </span>
              </div>

              <div>
                <h3 className="text-base font-bold text-slate-100 group-hover:text-emerald-400 transition-colors">
                  {item.diseaseName}
                </h3>
                <span className="text-[11px] text-slate-500 font-mono">ID: #{item.diseaseId}</span>
              </div>

              <p className="text-xs text-slate-400 line-clamp-2 leading-relaxed">
                <strong className="text-slate-300">Symptoms:</strong> {item.symptoms}
              </p>

              <p className="text-xs text-slate-400 line-clamp-2 leading-relaxed">
                <strong className="text-slate-300">Weather:</strong> {item.favorableConditions}
              </p>
            </div>

            <div className="pt-4 mt-3 border-t border-slate-800 flex items-center justify-between gap-2">
              <button
                onClick={() => setActiveModalRecord(item)}
                className="text-xs text-slate-300 hover:text-white font-medium flex items-center gap-1 transition-colors"
              >
                <span>View 13 Columns</span>
                <ChevronRight className="w-3.5 h-3.5" />
              </button>

              <button
                onClick={() => onSelectForTesting(item.crop, item.diseaseName)}
                className="px-2.5 py-1 rounded-lg text-xs font-semibold bg-emerald-950 text-emerald-300 hover:bg-emerald-900/80 border border-emerald-800/80 flex items-center gap-1.5 transition-colors"
                title="Load crop and disease directly into Risk Advisory Tester"
              >
                <Sparkles className="w-3 h-3 text-emerald-400" />
                <span>Test Risk</span>
              </button>
            </div>
          </div>
        ))}
      </div>

      {filteredRecords.length === 0 && (
        <div className="p-12 text-center bg-slate-900 border border-slate-800 rounded-2xl text-slate-400">
          <p className="text-sm">No disease records matched your filter criteria.</p>
          <button
            onClick={() => {
              setSearchTerm('');
              setSelectedCrop('ALL');
              setSelectedPathogen('ALL');
            }}
            className="mt-3 px-3 py-1.5 rounded-lg text-xs font-medium bg-slate-800 text-emerald-400 border border-slate-700"
          >
            Clear Filters
          </button>
        </div>
      )}

      {/* Detail Modal showing all 13 columns */}
      {activeModalRecord && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 sm:p-6 overflow-y-auto">
          <div className="bg-slate-900 border border-slate-700 rounded-2xl max-w-2xl w-full max-h-[90vh] flex flex-col shadow-2xl overflow-hidden">
            {/* Modal Header */}
            <div className="p-5 border-b border-slate-800 flex items-center justify-between bg-slate-950/80">
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-xs font-semibold px-2.5 py-0.5 rounded bg-emerald-950 text-emerald-300 border border-emerald-800">
                    {activeModalRecord.crop}
                  </span>
                  <span
                    className={`text-xs font-mono px-2 py-0.5 rounded border ${getPathogenColor(
                      activeModalRecord.pathogenType
                    )}`}
                  >
                    {activeModalRecord.pathogenType}
                  </span>
                  <span className="text-xs text-slate-500 font-mono">
                    ID: #{activeModalRecord.diseaseId}
                  </span>
                </div>
                <h3 className="text-xl font-bold text-slate-100 mt-1">
                  {activeModalRecord.diseaseName}
                </h3>
              </div>
              <button
                onClick={() => setActiveModalRecord(null)}
                className="p-2 rounded-lg bg-slate-800 text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Body */}
            <div className="p-5 overflow-y-auto space-y-4 text-xs">
              <div className="space-y-1">
                <span className="font-bold text-slate-300 uppercase tracking-wider text-[11px] flex items-center gap-1.5">
                  <Stethoscope className="w-3.5 h-3.5 text-amber-400" /> Symptoms
                </span>
                <p className="text-slate-300 bg-slate-950 p-3 rounded-xl border border-slate-800">
                  {activeModalRecord.symptoms}
                </p>
              </div>

              <div className="space-y-1">
                <span className="font-bold text-slate-300 uppercase tracking-wider text-[11px] flex items-center gap-1.5">
                  <Thermometer className="w-3.5 h-3.5 text-sky-400" /> Favorable Conditions
                </span>
                <p className="text-slate-300 bg-slate-950 p-3 rounded-xl border border-slate-800">
                  {activeModalRecord.favorableConditions}
                </p>
              </div>

              {/* Three Risk Tier Advisories */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="p-3 rounded-xl bg-emerald-950/20 border border-emerald-800/40 space-y-1">
                  <span className="font-bold text-emerald-400 uppercase tracking-wider text-[10px]">
                    Low Risk Advisory (&lt;0.4)
                  </span>
                  <p className="text-slate-300 text-[11px] leading-relaxed">
                    {activeModalRecord.lowRiskAdvisory}
                  </p>
                </div>
                <div className="p-3 rounded-xl bg-amber-950/20 border border-amber-800/40 space-y-1">
                  <span className="font-bold text-amber-400 uppercase tracking-wider text-[10px]">
                    Medium Risk Advisory (0.4-0.7)
                  </span>
                  <p className="text-slate-300 text-[11px] leading-relaxed">
                    {activeModalRecord.mediumRiskAdvisory}
                  </p>
                </div>
                <div className="p-3 rounded-xl bg-red-950/20 border border-red-800/40 space-y-1">
                  <span className="font-bold text-red-400 uppercase tracking-wider text-[10px]">
                    High Risk Advisory (&gt;0.7)
                  </span>
                  <p className="text-slate-300 text-[11px] leading-relaxed">
                    {activeModalRecord.highRiskAdvisory}
                  </p>
                </div>
              </div>

              {/* Preventative, Organic, Chemical */}
              <div className="space-y-2.5">
                <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
                  <span className="font-bold text-slate-300 uppercase tracking-wider text-[10px] block mb-1">
                    Preventive Measures:
                  </span>
                  <p className="text-slate-300">{activeModalRecord.preventiveMeasures}</p>
                </div>

                <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
                  <span className="font-bold text-teal-300 uppercase tracking-wider text-[10px] block mb-1">
                    Organic Treatment:
                  </span>
                  <p className="text-slate-300">{activeModalRecord.organicTreatment}</p>
                </div>

                <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
                  <span className="font-bold text-indigo-300 uppercase tracking-wider text-[10px] block mb-1">
                    Chemical Treatment Class:
                  </span>
                  <p className="text-slate-300">{activeModalRecord.chemicalTreatment}</p>
                </div>

                <div className="p-3 rounded-xl bg-amber-950/30 border border-amber-800/60">
                  <span className="font-bold text-amber-300 uppercase tracking-wider text-[10px] block mb-1">
                    Expert Advisory Escalation:
                  </span>
                  <p className="text-amber-200/90">{activeModalRecord.expertAdvisory}</p>
                </div>
              </div>
            </div>

            {/* Modal Footer */}
            <div className="p-4 border-t border-slate-800 bg-slate-950/80 flex items-center justify-between">
              <span className="text-xs text-slate-400">
                Mapped to JPA Entity <code className="text-emerald-400">DiseaseAdvisory</code>
              </span>
              <button
                onClick={() => {
                  onSelectForTesting(activeModalRecord.crop, activeModalRecord.diseaseName);
                  setActiveModalRecord(null);
                }}
                className="px-4 py-2 rounded-xl text-xs font-bold bg-emerald-500 hover:bg-emerald-400 text-slate-950 flex items-center gap-1.5 transition-colors"
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span>Test in Risk Calculator</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
