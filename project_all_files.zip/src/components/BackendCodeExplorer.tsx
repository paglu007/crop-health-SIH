import React, { useState } from 'react';
import {
  Folder,
  FileCode,
  Copy,
  Check,
  Code2,
  Terminal,
  Layers,
  ChevronRight,
  Database,
  ExternalLink,
} from 'lucide-react';

interface CodeFile {
  id: string;
  name: string;
  package: string;
  description: string;
  code: string;
}

const JAVA_FILES: CodeFile[] = [
  {
    id: 'pom',
    name: 'pom.xml',
    package: 'Project Root',
    description: 'Maven build configuration with Spring Boot 3.2, Data JPA, H2 In-Memory DB, and Apache Commons CSV.',
    code: `<?xml version="1.0" encoding="UTF-8"?>
<project xmlns="http://maven.apache.org/POM/4.0.0"
         xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
         xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 https://maven.apache.org/xsd/maven-4.0.0.xsd">
    <modelVersion>4.0.0</modelVersion>

    <parent>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-parent</artifactId>
        <version>3.2.4</version>
        <relativePath/>
    </parent>

    <groupId>com.cropapp</groupId>
    <artifactId>crop-disease-risk-advisory</artifactId>
    <version>1.0.0-SNAPSHOT</version>
    <name>Crop Disease Risk Advisory System</name>
    <description>SIH 2026 Crop Disease Risk Advisory Backend in Spring Boot</description>

    <properties>
        <java.version>17</java.version>
        <commons-csv.version>1.10.0</commons-csv.version>
    </properties>

    <dependencies>
        <!-- Spring Boot Web Starter for REST Endpoints -->
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-web</artifactId>
        </dependency>

        <!-- Spring Data JPA for Database Persistence -->
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-data-jpa</artifactId>
        </dependency>

        <!-- Bean Validation -->
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-validation</artifactId>
        </dependency>

        <!-- H2 In-Memory Database for rapid testing & hackathon demo -->
        <dependency>
            <groupId>com.h2database</groupId>
            <artifactId>h2</artifactId>
            <scope>runtime</scope>
        </dependency>

        <!-- Apache Commons CSV Parser (Handles quoted fields containing commas) -->
        <dependency>
            <groupId>org.apache.commons</groupId>
            <artifactId>commons-csv</artifactId>
            <version>\${commons-csv.version}</version>
        </dependency>

        <!-- Spring Boot Test Starter for Integration Tests -->
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-test</artifactId>
            <scope>test</scope>
        </dependency>
    </dependencies>

    <build>
        <plugins>
            <plugin>
                <groupId>org.springframework.boot</groupId>
                <artifactId>spring-boot-maven-plugin</artifactId>
            </plugin>
        </plugins>
    </build>
</project>`
  },
  {
    id: 'entity',
    name: 'DiseaseAdvisory.java',
    package: 'com.cropapp.advisory',
    description: 'JPA Entity mapping all 13 columns with @Column(length = 1000) and unique lookup index on (crop, disease_name).',
    code: `package com.cropapp.advisory;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Index;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;

/**
 * JPA Entity mapping crop disease advisory records from the SIH 2026 dataset.
 * Includes indexes and unique constraints on (crop, disease_name) for rapid lookup.
 */
@Entity
@Table(
    name = "disease_advisory",
    indexes = {
        @Index(name = "idx_crop_disease", columnList = "crop, disease_name"),
        @Index(name = "idx_pathogen_type", columnList = "pathogen_type")
    },
    uniqueConstraints = {
        @UniqueConstraint(name = "uk_crop_disease", columnNames = {"crop", "disease_name"})
    }
)
public class DiseaseAdvisory {

    @Id
    @Column(name = "disease_id")
    private Long diseaseId;

    @Column(name = "crop", nullable = false, length = 100)
    private String crop;

    @Column(name = "disease_name", nullable = false, length = 150)
    private String diseaseName;

    @Column(name = "pathogen_type", nullable = false, length = 100)
    private String pathogenType;

    @Column(name = "symptoms", length = 1000)
    private String symptoms;

    @Column(name = "favorable_conditions", length = 1000)
    private String favorableConditions;

    @Column(name = "low_risk_advisory", length = 1000)
    private String lowRiskAdvisory;

    @Column(name = "medium_risk_advisory", length = 1000)
    private String mediumRiskAdvisory;

    @Column(name = "high_risk_advisory", length = 1000)
    private String highRiskAdvisory;

    @Column(name = "expert_advisory", length = 1000)
    private String expertAdvisory;

    @Column(name = "preventive_measures", length = 1000)
    private String preventiveMeasures;

    @Column(name = "organic_treatment", length = 1000)
    private String organicTreatment;

    @Column(name = "chemical_treatment", length = 1000)
    private String chemicalTreatment;

    public DiseaseAdvisory() {}

    // Getters and Setters omitted for brevity...
}`
  },
  {
    id: 'repo',
    name: 'DiseaseAdvisoryRepository.java',
    package: 'com.cropapp.repository',
    description: 'Spring Data JPA Repository providing findByCropIgnoreCaseAndDiseaseNameIgnoreCase & findByPathogenType.',
    code: `package com.cropapp.repository;

import com.cropapp.advisory.DiseaseAdvisory;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * Spring Data JPA Repository for querying DiseaseAdvisory records.
 */
@Repository
public interface DiseaseAdvisoryRepository extends JpaRepository<DiseaseAdvisory, Long> {

    /**
     * Case-insensitive lookup matching crop and disease name.
     */
    Optional<DiseaseAdvisory> findByCropIgnoreCaseAndDiseaseNameIgnoreCase(String crop, String diseaseName);

    /**
     * Finds all advisory records belonging to a given pathogen type.
     */
    List<DiseaseAdvisory> findByPathogenType(String pathogenType);

    /**
     * Finds all records for a given crop.
     */
    List<DiseaseAdvisory> findByCropIgnoreCase(String crop);
}`
  },
  {
    id: 'risk-calc',
    name: 'RiskCalculator.java',
    package: 'com.cropapp.risk',
    description: 'Implements composite risk formula: 0.6*cvConfidence + 0.4*weatherRiskScore with LOW, MEDIUM, HIGH thresholds.',
    code: `package com.cropapp.risk;

import org.springframework.stereotype.Service;
import java.math.BigDecimal;
import java.math.RoundingMode;

/**
 * Service responsible for computing composite disease outbreak risk scores.
 * Formula: finalRisk = 0.6 * cvConfidence + 0.4 * weatherRiskScore
 * Thresholds:
 *   - LOW:    finalRisk < 0.4
 *   - MEDIUM: finalRisk in [0.4, 0.7]
 *   - HIGH:   finalRisk > 0.7
 */
@Service
public class RiskCalculator {

    private static final double CV_WEIGHT = 0.6;
    private static final double WEATHER_WEIGHT = 0.4;

    public RiskResult calculate(double cvConfidence, double weatherRiskScore) {
        if (cvConfidence < 0.0 || cvConfidence > 1.0) {
            throw new IllegalArgumentException("cvConfidence must be between 0.0 and 1.0.");
        }
        if (weatherRiskScore < 0.0 || weatherRiskScore > 1.0) {
            throw new IllegalArgumentException("weatherRiskScore must be between 0.0 and 1.0.");
        }

        double rawFinalRisk = (CV_WEIGHT * cvConfidence) + (WEATHER_WEIGHT * weatherRiskScore);
        
        double finalRisk = BigDecimal.valueOf(rawFinalRisk)
                .setScale(4, RoundingMode.HALF_UP)
                .doubleValue();

        RiskLevel level = RiskLevel.fromScore(finalRisk);

        return new RiskResult(cvConfidence, weatherRiskScore, finalRisk, level);
    }
}`
  },
  {
    id: 'service',
    name: 'AdvisoryService.java',
    package: 'com.cropapp.advisory',
    description: 'Business service returning full AdvisoryResponse with selected risk advisory text and non-throwing fallback.',
    code: `package com.cropapp.advisory;

import com.cropapp.dto.AdvisoryRequest;
import com.cropapp.dto.AdvisoryResponse;
import com.cropapp.repository.DiseaseAdvisoryRepository;
import com.cropapp.risk.RiskCalculator;
import com.cropapp.risk.RiskLevel;
import com.cropapp.risk.RiskResult;
import org.springframework.stereotype.Service;

import java.util.Optional;

/**
 * Core business service for resolving disease advisories and assembling complete responses.
 * Retrieves all 12 agronomic fields, selects the risk-appropriate advisory text,
 * and returns safe fallback advisories when records are not found.
 */
@Service
public class AdvisoryService {

    private final DiseaseAdvisoryRepository repository;
    private final RiskCalculator riskCalculator;

    public AdvisoryService(DiseaseAdvisoryRepository repository, RiskCalculator riskCalculator) {
        this.repository = repository;
        this.riskCalculator = riskCalculator;
    }

    public AdvisoryResponse getAdvisory(String crop, String diseaseName, RiskLevel level, Double finalRiskScore) {
        Optional<DiseaseAdvisory> recordOpt = repository.findByCropIgnoreCaseAndDiseaseNameIgnoreCase(
                crop != null ? crop.trim() : "",
                diseaseName != null ? diseaseName.trim() : ""
        );

        if (recordOpt.isEmpty()) {
            return buildFallbackResponse(crop, diseaseName, level, finalRiskScore);
        }

        DiseaseAdvisory record = recordOpt.get();

        String selectedAdvisoryText = switch (level) {
            case LOW -> record.getLowRiskAdvisory();
            case MEDIUM -> record.getMediumRiskAdvisory();
            case HIGH -> record.getHighRiskAdvisory();
        };

        return new AdvisoryResponse(
                record.getCrop(),
                record.getDiseaseName(),
                record.getPathogenType(),
                record.getSymptoms(),
                record.getFavorableConditions(),
                level,
                finalRiskScore,
                selectedAdvisoryText,
                record.getPreventiveMeasures(),
                record.getOrganicTreatment(),
                record.getChemicalTreatment(),
                record.getExpertAdvisory(), // Always included
                true
        );
    }

    public AdvisoryResponse processAdvisory(AdvisoryRequest request) {
        RiskResult riskResult = riskCalculator.calculate(request.getCvConfidence(), request.getWeatherRiskScore());
        return getAdvisory(request.getCrop(), request.getDiseaseName(), riskResult.getRiskLevel(), riskResult.getFinalRiskScore());
    }

    private AdvisoryResponse buildFallbackResponse(String crop, String diseaseName, RiskLevel level, Double finalRiskScore) {
        return new AdvisoryResponse(
                crop, diseaseName, "unclassified",
                "Symptoms could not be verified automatically.",
                "High relative humidity and moderate temperatures generally favor plant disease outbreaks.",
                level, finalRiskScore,
                "A specific advisory profile is not registered in our local dataset. Please contact your nearest Krishi Vigyan Kendra (KVK).",
                "Plant certified disease-free seeds and maintain clean field sanitation.",
                "Apply broad-spectrum organic bio-protectants such as Trichoderma viride or neem oil.",
                "Do not apply unverified synthetic chemicals without an official prescription.",
                "Please consult your local agricultural extension officer or call Kisan Call Center (1800-180-1551).",
                false
        );
    }
}`
  },
  {
    id: 'controller',
    name: 'AdvisoryController.java',
    package: 'com.cropapp.advisory',
    description: 'REST Controller exposing the primary SIH 2026 POST /api/advisory endpoint.',
    code: `package com.cropapp.advisory;

import com.cropapp.dto.AdvisoryRequest;
import com.cropapp.dto.AdvisoryResponse;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*")
public class AdvisoryController {

    private final AdvisoryService advisoryService;

    public AdvisoryController(AdvisoryService advisoryService) {
        this.advisoryService = advisoryService;
    }

    /**
     * Primary SIH 2026 REST Endpoint: POST /api/advisory
     */
    @PostMapping("/advisory")
    public ResponseEntity<AdvisoryResponse> calculateAdvisory(@Valid @RequestBody AdvisoryRequest request) {
        AdvisoryResponse response = advisoryService.processAdvisory(request);
        return ResponseEntity.ok(response);
    }
}`
  },
  {
    id: 'loader',
    name: 'CsvDataLoader.java',
    package: 'com.cropapp.config',
    description: 'CommandLineRunner that safely loads plant_disease_advisory_dataset.csv using Apache Commons CSV.',
    code: `package com.cropapp.config;

import com.cropapp.advisory.DiseaseAdvisory;
import com.cropapp.repository.DiseaseAdvisoryRepository;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;
import org.springframework.boot.CommandLineRunner;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.stereotype.Component;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/**
 * Startup CommandLineRunner that parses plant_disease_advisory_dataset.csv using Apache Commons CSV.
 * Handles quoted text containing internal commas safely without corrupted column offsets.
 */
@Component
public class CsvDataLoader implements CommandLineRunner {

    private final DiseaseAdvisoryRepository repository;
    private final ResourceLoader resourceLoader;

    public CsvDataLoader(DiseaseAdvisoryRepository repository, ResourceLoader resourceLoader) {
        this.repository = repository;
        this.resourceLoader = resourceLoader;
    }

    @Override
    public void run(String... args) throws Exception {
        Resource resource = resourceLoader.getResource("classpath:plant_disease_advisory_dataset.csv");
        if (!resource.exists()) {
            resource = resourceLoader.getResource("file:plant_disease_advisory_dataset.csv");
        }

        CSVFormat csvFormat = CSVFormat.DEFAULT.builder()
                .setHeader()
                .setSkipHeaderRecord(true)
                .setIgnoreHeaderCase(true)
                .setTrim(true)
                .build();

        List<DiseaseAdvisory> recordsToSave = new ArrayList<>();

        try (BufferedReader reader = new BufferedReader(
                new InputStreamReader(resource.getInputStream(), StandardCharsets.UTF_8));
             CSVParser csvParser = new CSVParser(reader, csvFormat)) {

            for (CSVRecord record : csvParser) {
                Long diseaseId = Long.parseLong(record.get("disease_id"));
                recordsToSave.add(new DiseaseAdvisory(
                        diseaseId,
                        record.get("crop"),
                        record.get("disease_name"),
                        record.get("pathogen_type"),
                        record.get("symptoms"),
                        record.get("favorable_conditions"),
                        record.get("low_risk_advisory"),
                        record.get("medium_risk_advisory"),
                        record.get("high_risk_advisory"),
                        record.get("expert_advisory"),
                        record.get("preventive_measures"),
                        record.get("organic_treatment"),
                        record.get("chemical_treatment")
                ));
            }
            repository.saveAll(recordsToSave);
        }
    }
}`
  },
  {
    id: 'test',
    name: 'DiseaseAdvisoryIntegrationTest.java',
    package: 'com.cropapp.advisory (Test)',
    description: 'Spring Boot Integration Test verifying dataset loading, Tomato Early Blight query, risk formula, and fallback.',
    code: `package com.cropapp.advisory;

import com.cropapp.dto.AdvisoryRequest;
import com.cropapp.dto.AdvisoryResponse;
import com.cropapp.repository.DiseaseAdvisoryRepository;
import com.cropapp.risk.RiskCalculator;
import com.cropapp.risk.RiskLevel;
import com.cropapp.risk.RiskResult;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
public class DiseaseAdvisoryIntegrationTest {

    @Autowired
    private DiseaseAdvisoryRepository repository;

    @Autowired
    private AdvisoryService advisoryService;

    @Autowired
    private RiskCalculator riskCalculator;

    @Test
    @DisplayName("Verify CSV dataset loaded into database on startup")
    public void testDatabaseContainsLoadedRecords() {
        assertTrue(repository.count() >= 140);
    }

    @Test
    @DisplayName("Verify RiskCalculator computes final risk and assigns HIGH risk level")
    public void testRiskCalculator() {
        RiskResult result = riskCalculator.calculate(0.82, 0.75);
        assertEquals(0.792, result.getFinalRiskScore(), 0.001);
        assertEquals(RiskLevel.HIGH, result.getRiskLevel());
    }

    @Test
    @DisplayName("Verify Repository lookup and full AdvisoryResponse population for Tomato + Early Blight")
    public void testTomatoEarlyBlightAdvisoryAllFieldsPopulated() {
        AdvisoryRequest request = new AdvisoryRequest("Tomato", "Early Blight", 0.82, 0.75);
        AdvisoryResponse response = advisoryService.processAdvisory(request);

        assertNotNull(response);
        assertTrue(response.isRecordFound());
        assertEquals("Tomato", response.getCrop());
        assertEquals("Early Blight", response.getDiseaseName());
        assertEquals("fungal_blight", response.getPathogenType());
        assertEquals(RiskLevel.HIGH, response.getRiskLevel());
        assertNotNull(response.getExpertAdvisory());
        assertTrue(response.getRiskAdvisory().contains("Conditions are strongly favorable"));
    }
}`
  }
];

export const BackendCodeExplorer: React.FC = () => {
  const [selectedFileId, setSelectedFileId] = useState('entity');
  const [copied, setCopied] = useState(false);

  const selectedFile = JAVA_FILES.find((f) => f.id === selectedFileId) || JAVA_FILES[0];

  const handleCopy = () => {
    navigator.clipboard.writeText(selectedFile.code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 sm:p-6 shadow-sm">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-950 text-emerald-300 border border-emerald-800">
                Spring Boot 3.2 &middot; Java 17
              </span>
              <span className="text-xs text-slate-400 font-mono">com.cropapp.*</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-bold text-slate-100 mt-2 flex items-center gap-2">
              <Code2 className="w-6 h-6 text-emerald-400" />
              Spring Boot Architecture & Source Code Explorer
            </h2>
            <p className="text-xs sm:text-sm text-slate-400 mt-1 max-w-3xl">
              Clean separation of concerns: JPA Entity mapping 13 columns, CSV DataLoader with Apache Commons CSV,
              JpaRepository with case-insensitive queries, weighted RiskCalculator service, AdvisoryService with fallback,
              and full JUnit integration tests.
            </p>
          </div>
        </div>
      </div>

      {/* Package Structure Diagram Card */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-3">
        <h3 className="text-sm font-bold text-slate-200 flex items-center gap-2 border-b border-slate-800 pb-3">
          <Layers className="w-4 h-4 text-emerald-400" />
          Java Package & Class Structure Overview
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-5 gap-3 text-xs">
          <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
            <span className="font-bold text-emerald-400 font-mono block">com.cropapp.advisory</span>
            <span className="text-[11px] text-slate-400 block">&bull; DiseaseAdvisory (Entity)</span>
            <span className="text-[11px] text-slate-400 block">&bull; AdvisoryService (Core)</span>
            <span className="text-[11px] text-slate-400 block">&bull; AdvisoryController (REST)</span>
          </div>
          <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
            <span className="font-bold text-sky-400 font-mono block">com.cropapp.risk</span>
            <span className="text-[11px] text-slate-400 block">&bull; RiskCalculator (0.6*CV+0.4*W)</span>
            <span className="text-[11px] text-slate-400 block">&bull; RiskLevel (LOW/MED/HIGH)</span>
            <span className="text-[11px] text-slate-400 block">&bull; RiskResult (Result DTO)</span>
          </div>
          <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
            <span className="font-bold text-purple-400 font-mono block">com.cropapp.repository</span>
            <span className="text-[11px] text-slate-400 block">&bull; DiseaseAdvisoryRepository</span>
            <span className="text-[11px] text-slate-400 block">&bull; findByCropAndDisease</span>
            <span className="text-[11px] text-slate-400 block">&bull; findByPathogenType</span>
          </div>
          <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
            <span className="font-bold text-amber-400 font-mono block">com.cropapp.dto</span>
            <span className="text-[11px] text-slate-400 block">&bull; AdvisoryRequest (Validation)</span>
            <span className="text-[11px] text-slate-400 block">&bull; AdvisoryResponse (12 fields)</span>
          </div>
          <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
            <span className="font-bold text-teal-400 font-mono block">com.cropapp.config</span>
            <span className="text-[11px] text-slate-400 block">&bull; CsvDataLoader (Runner)</span>
            <span className="text-[11px] text-slate-400 block">&bull; Apache Commons CSV</span>
          </div>
        </div>
      </div>

      {/* Code Viewer: File Sidebar + Code Box */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: File List */}
        <div className="lg:col-span-4 space-y-2">
          <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider block px-1">
            Backend Source Files
          </span>
          <div className="space-y-1.5">
            {JAVA_FILES.map((file) => {
              const isSelected = file.id === selectedFileId;
              return (
                <button
                  key={file.id}
                  onClick={() => setSelectedFileId(file.id)}
                  className={`w-full text-left p-3 rounded-xl text-xs transition-all flex items-start justify-between ${
                    isSelected
                      ? 'bg-emerald-500/15 text-emerald-300 border border-emerald-500/30 shadow-sm'
                      : 'bg-slate-900 hover:bg-slate-800/80 text-slate-300 border border-slate-800'
                  }`}
                >
                  <div className="space-y-0.5">
                    <div className="flex items-center gap-2">
                      <FileCode className={`w-3.5 h-3.5 ${isSelected ? 'text-emerald-400' : 'text-slate-400'}`} />
                      <span className="font-mono font-bold text-slate-100">{file.name}</span>
                    </div>
                    <span className="text-[11px] text-slate-500 font-mono block">{file.package}</span>
                  </div>
                  <ChevronRight className={`w-4 h-4 shrink-0 mt-1 ${isSelected ? 'text-emerald-400' : 'text-slate-600'}`} />
                </button>
              );
            })}
          </div>

          {/* Quick CLI Guide */}
          <div className="mt-4 p-4 rounded-xl bg-slate-900 border border-slate-800 space-y-2 text-xs">
            <span className="font-bold text-slate-200 flex items-center gap-1.5">
              <Terminal className="w-3.5 h-3.5 text-emerald-400" />
              How to Run Locally:
            </span>
            <p className="text-slate-400 text-[11px]">
              Navigate to the <code className="text-emerald-400">spring-boot-backend</code> directory and execute:
            </p>
            <pre className="p-2.5 rounded bg-slate-950 font-mono text-[11px] text-slate-200 border border-slate-800">
              ./mvnw spring-boot:run
            </pre>
            <p className="text-slate-500 text-[10px]">
              Or open the folder in IntelliJ IDEA / VS Code with Java Extension Pack.
            </p>
          </div>
        </div>

        {/* Right Column: Active File Code */}
        <div className="lg:col-span-8 space-y-3">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-3 shadow-sm">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-xs font-mono font-bold text-emerald-400">
                    {selectedFile.name}
                  </span>
                  <span className="text-[11px] text-slate-500 font-mono">
                    ({selectedFile.package})
                  </span>
                </div>
                <p className="text-xs text-slate-400 mt-0.5">
                  {selectedFile.description}
                </p>
              </div>

              <button
                onClick={handleCopy}
                className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs flex items-center gap-1.5 transition-colors border border-slate-700 shrink-0"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copied ? 'Copied' : 'Copy Code'}</span>
              </button>
            </div>

            <pre className="p-4 rounded-xl bg-slate-950 border border-slate-800 text-[11px] font-mono text-slate-300 overflow-x-auto max-h-[600px] leading-relaxed">
              {selectedFile.code}
            </pre>
          </div>
        </div>
      </div>
    </div>
  );
};
