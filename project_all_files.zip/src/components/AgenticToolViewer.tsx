import React, { useState } from 'react';
import {
  Bot,
  ShieldCheck,
  Code2,
  Copy,
  Check,
  Sparkles,
  ArrowRight,
  MessageSquare,
  AlertOctagon,
  Terminal,
} from 'lucide-react';

const LLM_TOOL_SCHEMA = {
  name: "get_crop_disease_advisory",
  description: "Retrieves authoritative agronomic advisory, risk score (0.6*CV + 0.4*Weather), symptoms, weather conditions, preventive measures, organic controls, chemical classes, and expert escalation guidance for crop diseases.",
  parameters: {
    type: "object",
    properties: {
      crop: {
        type: "string",
        description: "The standardized name of the crop (e.g., 'Tomato', 'Wheat', 'Rice')."
      },
      diseaseName: {
        type: "string",
        description: "The diagnosed plant disease name (e.g., 'Early Blight', 'Leaf Rust')."
      },
      cvConfidence: {
        type: "number",
        minimum: 0.0,
        maximum: 1.0,
        description: "Computer vision leaf disease identification confidence (0.0 to 1.0)."
      },
      weatherRiskScore: {
        type: "number",
        minimum: 0.0,
        maximum: 1.0,
        description: "Weather-based environmental outbreak index (0.0 to 1.0)."
      }
    },
    required: ["crop", "diseaseName", "cvConfidence", "weatherRiskScore"]
  }
};

const SYSTEM_GUARDRAIL_PROMPT = `// =========================================================================
// CRITICAL AGENTIC SAFETY GUARDRAIL (SIH 2026 MANDATE):
// The LLM agent must only relay the fields returned by 'get_crop_disease_advisory'
// conversationally to the farmer, and must NEVER invent its own treatment steps,
// dosages, or advice beyond what this endpoint returns.
// If the farmer requests unregistered dosages or commercial trade names,
// strictly refer them to the returned 'expertAdvisory' and their nearest
// Krishi Vigyan Kendra (KVK) or local Agricultural Extension Officer.
// =========================================================================

You are a trusted, empathetic Agricultural Advisory Assistant for Indian farmers.
When advising farmers on crop diseases:
1. Always call the 'get_crop_disease_advisory' tool with the identified crop and disease.
2. Ground 100% of your recommendations in the returned 'riskAdvisory', 'preventiveMeasures',
   'organicTreatment', and 'chemicalTreatment' fields.
3. NEVER fabricate chemical proportions, mix ratios, or unregistered pesticides.
4. Always convey the 'expertAdvisory' escalation advice if the risk level is HIGH or if
   symptoms persist after initial intervention.`;

const DEMO_SCENARIOS = [
  {
    title: "Tomato Early Blight (High Risk Outbreak)",
    userMessage: "Namaste! My tomato leaves have dark circular spots with yellow rings on lower leaves, and it has been raining continuously for 3 days with warm humid weather. What should I spray?",
    toolCall: {
      name: "get_crop_disease_advisory",
      arguments: {
        crop: "Tomato",
        diseaseName: "Early Blight",
        cvConfidence: 0.85,
        weatherRiskScore: 0.80
      }
    },
    agentResponse: `Namaste. Based on the symptoms and current weather conditions, here is your official advisory:

- Risk Level: HIGH (Composite Risk: 0.8300)
- Disease: Early Blight (Fungal Blight) affecting Tomato
- Immediate Action: Conditions are strongly favorable for rapid spread. Apply a recommended fungicide as per local agricultural extension guidance without delay and isolate severely affected plants.

Management Steps:
- Organic Control: Apply neem-based sprays, Trichoderma-based bio-fungicides, or certified copper-based organic fungicides to suppress early infection.
- Chemical Treatment: Apply an authorized contact or systemic fungicide approved by your local extension service at the first sign of spread.
- Prevention: Ensure clean field sanitation, rotate crops, and keep the plant canopy well-ventilated.

Expert Consultation:
Persistent or worsening Early Blight symptoms in Tomato despite treatment should be reported to a plant pathologist or agricultural extension officer for lab confirmation and updated regional advice.`
  },
  {
    title: "Wheat Leaf Rust (Medium Risk Early Detection)",
    userMessage: "I noticed small orange-brown pustules on my wheat leaves. Humidity is moderate around 70%. Should I take action now?",
    toolCall: {
      name: "get_crop_disease_advisory",
      arguments: {
        crop: "Wheat",
        diseaseName: "Leaf Rust",
        cvConfidence: 0.72,
        weatherRiskScore: 0.55
      }
    },
    agentResponse: `Based on your observation of orange pustules on wheat:

- Risk Level: MEDIUM (Composite Risk: 0.6520)
- Disease: Leaf Rust (Fungal Rust) affecting Wheat
- Advisory: Weather conditions are moderately favorable for rust development. Increase scouting frequency to every 2 to 3 days.

Recommended Protocol:
- Organic Option: Bio-fungicides like Trichoderma or Ampelomyces can help suppress mild rust development.
- Preventive Action: Plant rust-resistant cultivars, avoid excessive late nitrogen fertilizer applications, and remove volunteer wheat plants.
- Expert Advice: If rust pustules spread upward to the flag leaf, immediately consult your local KVK or agricultural officer for guidance.`
  }
];

export const AgenticToolViewer: React.FC = () => {
  const [copiedSchema, setCopiedSchema] = useState(false);
  const [copiedPrompt, setCopiedPrompt] = useState(false);
  const [selectedScenarioIdx, setSelectedScenarioIdx] = useState(0);

  const scenario = DEMO_SCENARIOS[selectedScenarioIdx];

  const handleCopySchema = () => {
    navigator.clipboard.writeText(JSON.stringify(LLM_TOOL_SCHEMA, null, 2));
    setCopiedSchema(true);
    setTimeout(() => setCopiedSchema(false), 2000);
  };

  const handleCopyPrompt = () => {
    navigator.clipboard.writeText(SYSTEM_GUARDRAIL_PROMPT);
    setCopiedPrompt(true);
    setTimeout(() => setCopiedPrompt(false), 2000);
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 sm:p-6 shadow-sm">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-indigo-950 text-indigo-300 border border-indigo-800">
                Agentic Tool Protocol
              </span>
              <span className="text-xs text-slate-400 font-mono">OpenAI / Gemini / LangChain</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-bold text-slate-100 mt-2 flex items-center gap-2">
              <Bot className="w-6 h-6 text-indigo-400" />
              Agentic AI Function Calling & Strict Agronomic Guardrails
            </h2>
            <p className="text-xs sm:text-sm text-slate-400 mt-1 max-w-3xl">
              Specification for autonomous AI agents connecting to <code className="text-emerald-400">POST /api/advisory</code>.
              Enforces zero-hallucination policies so agricultural recommendations remain authoritative and safe for farmers.
            </p>
          </div>
        </div>
      </div>

      {/* Strict Guardrail Notice */}
      <div className="p-4 sm:p-5 rounded-2xl bg-amber-950/20 border border-amber-800/50 flex items-start gap-3.5">
        <AlertOctagon className="w-6 h-6 text-amber-400 shrink-0 mt-0.5" />
        <div className="space-y-1">
          <h3 className="text-sm font-bold text-amber-300">
            Mandatory Agronomic AI Safety Directive:
          </h3>
          <p className="text-xs text-amber-200/90 leading-relaxed font-mono">
            "The LLM agent must only relay these fields conversationally to the farmer, and must NEVER invent its own treatment steps, dosages, or advice beyond what this endpoint returns."
          </p>
        </div>
      </div>

      {/* Two Column Layout: Schema on Left, Live Conversational Flow on Right */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Schema & System Prompt */}
        <div className="lg:col-span-6 space-y-6">
          {/* Function Calling JSON Schema */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-3 shadow-sm">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <Code2 className="w-4 h-4 text-emerald-400" />
                <h3 className="text-sm font-bold text-slate-200">
                  JSON Function Calling Schema
                </h3>
              </div>
              <button
                onClick={handleCopySchema}
                className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs flex items-center gap-1.5 transition-colors border border-slate-700"
              >
                {copiedSchema ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedSchema ? 'Copied' : 'Copy Schema'}</span>
              </button>
            </div>
            <pre className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 text-[11px] font-mono text-slate-300 overflow-x-auto max-h-80 leading-relaxed">
              {JSON.stringify(LLM_TOOL_SCHEMA, null, 2)}
            </pre>
          </div>

          {/* System Guardrail Prompt */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-3 shadow-sm">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-amber-400" />
                <h3 className="text-sm font-bold text-slate-200">
                  LLM Agent System Instructions & Guardrails
                </h3>
              </div>
              <button
                onClick={handleCopyPrompt}
                className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs flex items-center gap-1.5 transition-colors border border-slate-700"
              >
                {copiedPrompt ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedPrompt ? 'Copied' : 'Copy Prompt'}</span>
              </button>
            </div>
            <pre className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 text-[11px] font-mono text-amber-300/90 overflow-x-auto max-h-64 whitespace-pre-wrap leading-relaxed">
              {SYSTEM_GUARDRAIL_PROMPT}
            </pre>
          </div>
        </div>

        {/* Right Column: Interactive Conversational Simulation */}
        <div className="lg:col-span-6 space-y-6">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-4 shadow-sm">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <Terminal className="w-4 h-4 text-sky-400" />
                <h3 className="text-sm font-bold text-slate-200">
                  Live Agentic Execution Simulation
                </h3>
              </div>
              <span className="text-xs text-slate-500 font-mono">End-to-End Workflow</span>
            </div>

            {/* Scenario Picker */}
            <div className="flex gap-2">
              {DEMO_SCENARIOS.map((sc, idx) => (
                <button
                  key={sc.title}
                  onClick={() => setSelectedScenarioIdx(idx)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                    selectedScenarioIdx === idx
                      ? 'bg-sky-500 text-slate-950 font-bold'
                      : 'bg-slate-800 text-slate-400 hover:text-slate-200'
                  }`}
                >
                  Scenario {idx + 1}: {sc.title.split(' ')[0]} {sc.title.split(' ')[1]}
                </button>
              ))}
            </div>

            {/* Step 1: Farmer Prompt */}
            <div className="space-y-1.5">
              <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                <MessageSquare className="w-3.5 h-3.5 text-slate-400" />
                Step 1: Farmer Inquires via Voice/Chat
              </span>
              <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-200 leading-relaxed">
                "{scenario.userMessage}"
              </div>
            </div>

            {/* Step 2: Agent Tool Invocation */}
            <div className="space-y-1.5">
              <span className="text-[11px] font-bold uppercase tracking-wider text-sky-400 flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-sky-400" />
                Step 2: Autonomous LLM Tool Invocation
              </span>
              <div className="p-3.5 rounded-xl bg-slate-950 border border-sky-900/50 text-xs font-mono space-y-1">
                <div className="text-sky-300 font-semibold">
                  call {scenario.toolCall.name}(
                </div>
                <div className="pl-4 text-slate-300">
                  {JSON.stringify(scenario.toolCall.arguments, null, 2)}
                </div>
                <div className="text-sky-300 font-semibold">)</div>
              </div>
            </div>

            {/* Step 3: Conversational Output Strictly Grounded */}
            <div className="space-y-1.5">
              <span className="text-[11px] font-bold uppercase tracking-wider text-emerald-400 flex items-center gap-1.5">
                <Bot className="w-3.5 h-3.5 text-emerald-400" />
                Step 3: Grounded Farmer Advisory (Zero Hallucination)
              </span>
              <div className="p-4 rounded-xl bg-emerald-950/20 border border-emerald-800/40 text-xs text-slate-200 whitespace-pre-line leading-relaxed">
                {scenario.agentResponse}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
