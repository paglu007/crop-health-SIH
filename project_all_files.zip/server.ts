import express from "express";
import path from "path";
import fs from "fs";
import { parse } from "csv-parse/sync";
import { createServer as createViteServer } from "vite";

interface DiseaseRecord {
  diseaseId: number;
  crop: string;
  diseaseName: string;
  pathogenType: string;
  symptoms: string;
  favorableConditions: string;
  lowRiskAdvisory: string;
  mediumRiskAdvisory: string;
  highRiskAdvisory: string;
  expertAdvisory: string;
  preventiveMeasures: string;
  organicTreatment: string;
  chemicalTreatment: string;
}

const PORT = 3000;
const app = express();
app.use(express.json());

// In-memory dataset populated from plant_disease_advisory_dataset.csv
let diseaseRecords: DiseaseRecord[] = [];

function loadDataset() {
  const possiblePaths = [
    path.join(process.cwd(), "src", "data", "plant_disease_advisory_dataset.csv"),
    path.join(process.cwd(), "plant_disease_advisory_dataset.csv"),
    path.join(process.cwd(), "spring-boot-backend", "src", "main", "resources", "plant_disease_advisory_dataset.csv"),
  ];

  let csvPath = "";
  for (const p of possiblePaths) {
    if (fs.existsSync(p)) {
      csvPath = p;
      break;
    }
  }

  if (!csvPath) {
    console.error("Could not find plant_disease_advisory_dataset.csv");
    return;
  }

  const fileContent = fs.readFileSync(csvPath, "utf-8");
  const rawRows: Record<string, string>[] = parse(fileContent, {
    columns: true,
    skip_empty_lines: true,
    trim: true,
  });

  diseaseRecords = rawRows.map((row) => ({
    diseaseId: parseInt(row.disease_id, 10),
    crop: row.crop,
    diseaseName: row.disease_name,
    pathogenType: row.pathogen_type,
    symptoms: row.symptoms,
    favorableConditions: row.favorable_conditions,
    lowRiskAdvisory: row.low_risk_advisory,
    mediumRiskAdvisory: row.medium_risk_advisory,
    highRiskAdvisory: row.high_risk_advisory,
    expertAdvisory: row.expert_advisory,
    preventiveMeasures: row.preventive_measures,
    organicTreatment: row.organic_treatment,
    chemicalTreatment: row.chemical_treatment,
  }));

  console.log(`Loaded ${diseaseRecords.length} disease records from ${csvPath}`);
}

loadDataset();

// Helper: Risk Level Calculator (matching com.cropapp.risk.RiskCalculator)
function calculateRisk(cvConfidence: number, weatherRiskScore: number) {
  const finalRisk = Number((0.6 * cvConfidence + 0.4 * weatherRiskScore).toFixed(4));
  let riskLevel: "LOW" | "MEDIUM" | "HIGH" = "LOW";
  if (finalRisk < 0.4) {
    riskLevel = "LOW";
  } else if (finalRisk <= 0.7) {
    riskLevel = "MEDIUM";
  } else {
    riskLevel = "HIGH";
  }
  return { finalRisk, riskLevel };
}

// -------------------------------------------------------------
// REST API ENDPOINTS (matching Spring Boot controller)
// -------------------------------------------------------------

// Health check endpoint
app.get("/api/health", (req, res) => {
  res.json({
    status: "UP",
    service: "Crop Disease Risk Advisory System (SIH 2026)",
    recordsLoaded: diseaseRecords.length,
    timestamp: new Date().toISOString(),
  });
});

// List all crops
app.get("/api/crops", (req, res) => {
  const crops = Array.from(new Set(diseaseRecords.map((d) => d.crop))).sort();
  res.json(crops);
});

// List or search diseases
app.get("/api/diseases", (req, res) => {
  const { crop, pathogenType, search } = req.query;
  let filtered = diseaseRecords;

  if (typeof crop === "string" && crop.trim()) {
    filtered = filtered.filter((d) => d.crop.toLowerCase() === crop.trim().toLowerCase());
  }

  if (typeof pathogenType === "string" && pathogenType.trim()) {
    filtered = filtered.filter((d) => d.pathogenType.toLowerCase() === pathogenType.trim().toLowerCase());
  }

  if (typeof search === "string" && search.trim()) {
    const q = search.trim().toLowerCase();
    filtered = filtered.filter(
      (d) =>
        d.crop.toLowerCase().includes(q) ||
        d.diseaseName.toLowerCase().includes(q) ||
        d.pathogenType.toLowerCase().includes(q) ||
        d.symptoms.toLowerCase().includes(q)
    );
  }

  res.json(filtered);
});

// Main SIH 2026 Advisory Endpoint: POST /api/advisory
app.post("/api/advisory", (req, res) => {
  const { crop, diseaseName, cvConfidence, weatherRiskScore } = req.body;

  if (!crop || !diseaseName || cvConfidence === undefined || weatherRiskScore === undefined) {
    return res.status(400).json({
      error: "Missing required fields: crop, diseaseName, cvConfidence, weatherRiskScore",
    });
  }

  const cv = parseFloat(cvConfidence);
  const weather = parseFloat(weatherRiskScore);

  if (isNaN(cv) || isNaN(weather) || cv < 0 || cv > 1 || weather < 0 || weather > 1) {
    return res.status(400).json({
      error: "cvConfidence and weatherRiskScore must be numbers between 0.0 and 1.0",
    });
  }

  const { finalRisk, riskLevel } = calculateRisk(cv, weather);

  // Case-insensitive lookup (matching Spring Data repository findByCropIgnoreCaseAndDiseaseNameIgnoreCase)
  const record = diseaseRecords.find(
    (d) =>
      d.crop.trim().toLowerCase() === crop.trim().toLowerCase() &&
      d.diseaseName.trim().toLowerCase() === diseaseName.trim().toLowerCase()
  );

  if (!record) {
    // Fallback response with non-throwing graceful response
    return res.json({
      crop: crop.trim(),
      diseaseName: diseaseName.trim(),
      pathogenType: "unclassified",
      symptoms:
        "Symptoms could not be verified automatically. Inspect foliage for chlorosis, necrotic spotting, or sporulation.",
      favorableConditions:
        "High relative humidity (>80%), prolonged leaf wetness, and moderate temperatures generally favor plant disease outbreaks.",
      riskLevel,
      finalRiskScore: finalRisk,
      riskAdvisory: `A specific advisory profile for '${diseaseName}' in '${crop}' is not registered in our local dataset. Given a ${riskLevel} calculated risk score, we strongly advise inspecting foliage closely, isolating wilting plants, avoiding overhead watering, and contacting your local Krishi Vigyan Kendra (KVK) or District Agricultural Extension Office for diagnostic confirmation.`,
      preventiveMeasures:
        "Plant certified disease-free seeds, practice crop rotation, ensure clean field sanitation, and sanitize farm implements.",
      organicTreatment:
        "Apply broad-spectrum organic bio-protectants such as Trichoderma viride or neem oil (10,000 ppm) if early symptoms appear.",
      chemicalTreatment:
        "Do not apply unverified synthetic chemicals without an official prescription from your local agricultural officer.",
      expertAdvisory: `Please consult your local agricultural extension officer, state agriculture department helpline (Kisan Call Center: 1800-180-1551), or your nearest Krishi Vigyan Kendra (KVK) to confirm the pathogen and obtain approved regional recommendations for ${crop}.`,
      recordFound: false,
    });
  }

  // Select matching risk advisory text
  let selectedAdvisory = record.lowRiskAdvisory;
  if (riskLevel === "MEDIUM") {
    selectedAdvisory = record.mediumRiskAdvisory;
  } else if (riskLevel === "HIGH") {
    selectedAdvisory = record.highRiskAdvisory;
  }

  res.json({
    crop: record.crop,
    diseaseName: record.diseaseName,
    pathogenType: record.pathogenType,
    symptoms: record.symptoms,
    favorableConditions: record.favorableConditions,
    riskLevel,
    finalRiskScore: finalRisk,
    riskAdvisory: selectedAdvisory,
    preventiveMeasures: record.preventiveMeasures,
    organicTreatment: record.organicTreatment,
    chemicalTreatment: record.chemicalTreatment,
    expertAdvisory: record.expertAdvisory, // Always included as requested
    recordFound: true,
  });
});

// Vite middleware & SPA fallback
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Crop Disease Risk Advisory Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
