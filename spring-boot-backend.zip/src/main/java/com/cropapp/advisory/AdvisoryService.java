package com.cropapp.advisory;

import com.cropapp.dto.AdvisoryRequest;
import com.cropapp.dto.AdvisoryResponse;
import com.cropapp.repository.DiseaseAdvisoryRepository;
import com.cropapp.risk.RiskCalculator;
import com.cropapp.risk.RiskLevel;
import com.cropapp.risk.RiskResult;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.Optional;

/**
 * Core business service for resolving disease advisories and assembling complete responses.
 * Retrieves all 12 agronomic fields, selects the risk-appropriate advisory text based on RiskLevel,
 * and handles missing disease records safely without throwing exceptions.
 */
@Service
public class AdvisoryService {

    private static final Logger log = LoggerFactory.getLogger(AdvisoryService.class);

    private final DiseaseAdvisoryRepository repository;
    private final RiskCalculator riskCalculator;

    public AdvisoryService(DiseaseAdvisoryRepository repository, RiskCalculator riskCalculator) {
        this.repository = repository;
        this.riskCalculator = riskCalculator;
    }

    /**
     * Resolves complete advisory for a crop and disease at a specified RiskLevel.
     * Selects matching risk advisory text (low_risk_advisory, medium_risk_advisory, or high_risk_advisory).
     *
     * @param crop           target crop name (case-insensitive)
     * @param diseaseName    target disease name (case-insensitive)
     * @param level          the determined RiskLevel (LOW, MEDIUM, HIGH)
     * @return full AdvisoryResponse with all fields or a graceful fallback if unrecorded
     */
    public AdvisoryResponse getAdvisory(String crop, String diseaseName, RiskLevel level) {
        return getAdvisory(crop, diseaseName, level, null);
    }

    /**
     * Overloaded method including the computed numerical composite risk score.
     *
     * @param crop           target crop name (case-insensitive)
     * @param diseaseName    target disease name (case-insensitive)
     * @param level          the determined RiskLevel (LOW, MEDIUM, HIGH)
     * @param finalRiskScore computed composite risk score
     * @return full AdvisoryResponse with all fields or a graceful fallback if unrecorded
     */
    public AdvisoryResponse getAdvisory(String crop, String diseaseName, RiskLevel level, Double finalRiskScore) {
        log.info("Fetching advisory for crop='{}', disease='{}', riskLevel='{}'", crop, diseaseName, level);

        Optional<DiseaseAdvisory> recordOpt = repository.findByCropIgnoreCaseAndDiseaseNameIgnoreCase(
                crop != null ? crop.trim() : "",
                diseaseName != null ? diseaseName.trim() : ""
        );

        if (recordOpt.isEmpty()) {
            log.warn("No database entry for crop='{}' and disease='{}'. Returning fallback advisory.", crop, diseaseName);
            return buildFallbackResponse(crop, diseaseName, level, finalRiskScore);
        }

        DiseaseAdvisory record = recordOpt.get();

        // Dynamically select the exact risk-tier advisory text
        String selectedAdvisoryText = switch (level) {
            case LOW -> record.getLowRiskAdvisory();
            case MEDIUM -> record.getMediumRiskAdvisory();
            case HIGH -> record.getHighRiskAdvisory();
        };

        // If specific text is null/blank, fallback to available advisory text
        if (selectedAdvisoryText == null || selectedAdvisoryText.isBlank()) {
            selectedAdvisoryText = record.getMediumRiskAdvisory() != null ? record.getMediumRiskAdvisory() : record.getLowRiskAdvisory();
        }

        return new AdvisoryResponse(
                record.getCrop(),
                record.getDiseaseName(),
                record.getPathogenType(),
                record.getSymptoms(),
                record.getFavorableConditions(),
                level,
                finalRiskScore,
                selectedAdvisoryText,
                record.getPreventiveMeasures(),
                record.getOrganicTreatment(),
                record.getChemicalTreatment(),
                record.getExpertAdvisory(), // Always included so LLM agent can decide when to surface
                true
        );
    }

    /**
     * High-level convenience method processing an AdvisoryRequest end-to-end:
     * 1. Computes composite risk via RiskCalculator (0.6*CV + 0.4*Weather).
     * 2. Resolves and returns full AdvisoryResponse.
     *
     * @param request the validated AdvisoryRequest containing crop, disease, cvConfidence, weatherRiskScore
     * @return full AdvisoryResponse DTO
     */
    public AdvisoryResponse processAdvisory(AdvisoryRequest request) {
        RiskResult riskResult = riskCalculator.calculate(request.getCvConfidence(), request.getWeatherRiskScore());
        return getAdvisory(request.getCrop(), request.getDiseaseName(), riskResult.getRiskLevel(), riskResult.getFinalRiskScore());
    }

    /**
     * Builds a safe fallback advisory when a crop/disease combination is not found in the dataset.
     * Prevents runtime exceptions while providing safe, actionable agronomic advice.
     */
    private AdvisoryResponse buildFallbackResponse(String crop, String diseaseName, RiskLevel level, Double finalRiskScore) {
        String safeCrop = (crop != null && !crop.isBlank()) ? crop : "Unknown Crop";
        String safeDisease = (diseaseName != null && !diseaseName.isBlank()) ? diseaseName : "Unknown Condition";

        String genericAdvisory = String.format(
                "A specific advisory profile for '%s' affecting '%s' is not registered in our local dataset. " +
                "Given a %s calculated risk score, we strongly advise inspecting the foliage closely, isolating any heavily discolored " +
                "or wilting plants, avoiding excessive overhead irrigation, and contacting your local Krishi Vigyan Kendra (KVK) or " +
                "District Agricultural Extension Office for visual inspection and lab diagnostics.",
                safeDisease, safeCrop, level
        );

        String genericExpert = String.format(
                "Please consult your local agricultural extension officer, state agriculture department helpline (Kisan Call Center: 1800-180-1551), " +
                "or your nearest Krishi Vigyan Kendra (KVK) to confirm the pathogen and obtain approved regional recommendations for %s.",
                safeCrop
        );

        return new AdvisoryResponse(
                safeCrop,
                safeDisease,
                "unclassified",
                "Symptoms could not be verified automatically. Look for foliar chlorosis, necrotic spotting, wilting, or fungal sporulation.",
                "High relative humidity (>80%), prolonged leaf wetness, and moderate temperatures generally favor plant disease outbreaks.",
                level,
                finalRiskScore,
                genericAdvisory,
                "Plant certified disease-free seeds, practice crop rotation, ensure clean field sanitation, and sanitize farm implements.",
                "Apply broad-spectrum organic bio-protectants such as Trichoderma viride or neem oil (10,000 ppm) if early symptoms appear.",
                "Do not apply unverified synthetic chemicals without an official prescription from your local agricultural officer.",
                genericExpert,
                false
        );
    }
}
