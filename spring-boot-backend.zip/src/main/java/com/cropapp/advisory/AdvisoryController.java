package com.cropapp.advisory;

import com.cropapp.dto.AdvisoryRequest;
import com.cropapp.dto.AdvisoryResponse;
import com.cropapp.repository.DiseaseAdvisoryRepository;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;

/**
 * REST Controller exposing crop disease risk advisory endpoints.
 * Provides the primary SIH 2026 endpoint: POST /api/advisory
 */
@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*")
public class AdvisoryController {

    private final AdvisoryService advisoryService;
    private final DiseaseAdvisoryRepository repository;

    public AdvisoryController(AdvisoryService advisoryService, DiseaseAdvisoryRepository repository) {
        this.advisoryService = advisoryService;
        this.repository = repository;
    }

    /**
     * Primary SIH 2026 Hackathon REST Endpoint.
     * Computes final disease risk score (0.6 * cvConfidence + 0.4 * weatherRiskScore)
     * and returns the comprehensive advisory profile with symptoms, favorable conditions,
     * matched risk advisory text, prevention, organic and chemical controls, and expert guidance.
     *
     * @param request JSON payload with crop, diseaseName, cvConfidence, weatherRiskScore
     * @return 200 OK with full AdvisoryResponse DTO
     */
    @PostMapping("/advisory")
    public ResponseEntity<AdvisoryResponse> calculateAdvisory(@Valid @RequestBody AdvisoryRequest request) {
        AdvisoryResponse response = advisoryService.processAdvisory(request);
        return ResponseEntity.ok(response);
    }

    /**
     * Health check endpoint to verify backend status and total loaded records.
     *
     * @return service status and count of database records
     */
    @GetMapping("/health")
    public ResponseEntity<Map<String, Object>> healthCheck() {
        long count = repository.count();
        return ResponseEntity.ok(Map.of(
                "status", "UP",
                "service", "Crop Disease Risk Advisory System",
                "database", "H2 In-Memory",
                "recordsLoaded", count
        ));
    }

    /**
     * Helper endpoint to retrieve all records or filter by crop or pathogen type.
     *
     * @param crop         optional crop filter
     * @param pathogenType optional pathogen category filter
     * @return list of DiseaseAdvisory entities
     */
    @GetMapping("/diseases")
    public ResponseEntity<List<DiseaseAdvisory>> listDiseases(
            @RequestParam(required = false) String crop,
            @RequestParam(required = false) String pathogenType) {

        if (crop != null && !crop.isBlank()) {
            return ResponseEntity.ok(repository.findByCropIgnoreCase(crop));
        }
        if (pathogenType != null && !pathogenType.isBlank()) {
            return ResponseEntity.ok(repository.findByPathogenType(pathogenType));
        }
        return ResponseEntity.ok(repository.findAll());
    }
}
