package com.cropapp.advisory;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Index;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;

/**
 * JPA Entity mapping crop disease advisory records from the SIH 2026 dataset.
 * Includes indexes and unique constraints on (crop, disease_name) for rapid lookup.
 */
@Entity
@Table(
    name = "disease_advisory",
    indexes = {
        @Index(name = "idx_crop_disease", columnList = "crop, disease_name"),
        @Index(name = "idx_pathogen_type", columnList = "pathogen_type")
    },
    uniqueConstraints = {
        @UniqueConstraint(name = "uk_crop_disease", columnNames = {"crop", "disease_name"})
    }
)
public class DiseaseAdvisory {

    /**
     * Unique identifier for the disease record (primary key from CSV).
     */
    @Id
    @Column(name = "disease_id")
    private Long diseaseId;

    /**
     * Name of the target crop (e.g., "Wheat", "Tomato", "Rice").
     */
    @Column(name = "crop", nullable = false, length = 100)
    private String crop;

    /**
     * Name of the plant disease (e.g., "Early Blight", "Leaf Rust").
     */
    @Column(name = "disease_name", nullable = false, length = 150)
    private String diseaseName;

    /**
     * Pathogen classification type (e.g., fungal_blight, fungal_rust, bacterial, viral, nematode, phytoplasma, nutrient_disorder).
     */
    @Column(name = "pathogen_type", nullable = false, length = 100)
    private String pathogenType;

    /**
     * Observable visual symptoms and physical signs on plants.
     */
    @Column(name = "symptoms", length = 1000)
    private String symptoms;

    /**
     * Weather and environmental factors promoting outbreak.
     */
    @Column(name = "favorable_conditions", length = 1000)
    private String favorableConditions;

    /**
     * Specific agronomic guidance when computed risk is LOW (< 0.4).
     */
    @Column(name = "low_risk_advisory", length = 1000)
    private String lowRiskAdvisory;

    /**
     * Specific agronomic guidance when computed risk is MEDIUM (0.4 - 0.7).
     */
    @Column(name = "medium_risk_advisory", length = 1000)
    private String mediumRiskAdvisory;

    /**
     * Specific agronomic guidance when computed risk is HIGH (> 0.7).
     */
    @Column(name = "high_risk_advisory", length = 1000)
    private String highRiskAdvisory;

    /**
     * Directive advice advising when to escalate to an agricultural extension officer / KVK.
     */
    @Column(name = "expert_advisory", length = 1000)
    private String expertAdvisory;

    /**
     * Cultural, biological, and sanitary prevention practices.
     */
    @Column(name = "preventive_measures", length = 1000)
    private String preventiveMeasures;

    /**
     * Certified non-chemical and organic remedies.
     */
    @Column(name = "organic_treatment", length = 1000)
    private String organicTreatment;

    /**
     * Recommended chemical fungicide/bactericide classes (subject to local extension approval).
     */
    @Column(name = "chemical_treatment", length = 1000)
    private String chemicalTreatment;

    public DiseaseAdvisory() {
    }

    public DiseaseAdvisory(Long diseaseId, String crop, String diseaseName, String pathogenType,
                           String symptoms, String favorableConditions, String lowRiskAdvisory,
                           String mediumRiskAdvisory, String highRiskAdvisory, String expertAdvisory,
                           String preventiveMeasures, String organicTreatment, String chemicalTreatment) {
        this.diseaseId = diseaseId;
        this.crop = crop;
        this.diseaseName = diseaseName;
        this.pathogenType = pathogenType;
        this.symptoms = symptoms;
        this.favorableConditions = favorableConditions;
        this.lowRiskAdvisory = lowRiskAdvisory;
        this.mediumRiskAdvisory = mediumRiskAdvisory;
        this.highRiskAdvisory = highRiskAdvisory;
        this.expertAdvisory = expertAdvisory;
        this.preventiveMeasures = preventiveMeasures;
        this.organicTreatment = organicTreatment;
        this.chemicalTreatment = chemicalTreatment;
    }

    // Getters and Setters

    public Long getDiseaseId() {
        return diseaseId;
    }

    public void setDiseaseId(Long diseaseId) {
        this.diseaseId = diseaseId;
    }

    public String getCrop() {
        return crop;
    }

    public void setCrop(String crop) {
        this.crop = crop;
    }

    public String getDiseaseName() {
        return diseaseName;
    }

    public void setDiseaseName(String diseaseName) {
        this.diseaseName = diseaseName;
    }

    public String getPathogenType() {
        return pathogenType;
    }

    public void setPathogenType(String pathogenType) {
        this.pathogenType = pathogenType;
    }

    public String getSymptoms() {
        return symptoms;
    }

    public void setSymptoms(String symptoms) {
        this.symptoms = symptoms;
    }

    public String getFavorableConditions() {
        return favorableConditions;
    }

    public void setFavorableConditions(String favorableConditions) {
        this.favorableConditions = favorableConditions;
    }

    public String getLowRiskAdvisory() {
        return lowRiskAdvisory;
    }

    public void setLowRiskAdvisory(String lowRiskAdvisory) {
        this.lowRiskAdvisory = lowRiskAdvisory;
    }

    public String getMediumRiskAdvisory() {
        return mediumRiskAdvisory;
    }

    public void setMediumRiskAdvisory(String mediumRiskAdvisory) {
        this.mediumRiskAdvisory = mediumRiskAdvisory;
    }

    public String getHighRiskAdvisory() {
        return highRiskAdvisory;
    }

    public void setHighRiskAdvisory(String highRiskAdvisory) {
        this.highRiskAdvisory = highRiskAdvisory;
    }

    public String getExpertAdvisory() {
        return expertAdvisory;
    }

    public void setExpertAdvisory(String expertAdvisory) {
        this.expertAdvisory = expertAdvisory;
    }

    public String getPreventiveMeasures() {
        return preventiveMeasures;
    }

    public void setPreventiveMeasures(String preventiveMeasures) {
        this.preventiveMeasures = preventiveMeasures;
    }

    public String getOrganicTreatment() {
        return organicTreatment;
    }

    public void setOrganicTreatment(String organicTreatment) {
        this.organicTreatment = organicTreatment;
    }

    public String getChemicalTreatment() {
        return chemicalTreatment;
    }

    public void setChemicalTreatment(String chemicalTreatment) {
        this.chemicalTreatment = chemicalTreatment;
    }
}
