package com.cropapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Main entry point for the SIH 2026 Crop Disease Risk Advisory System backend.
 * Bootstraps Spring Boot, in-memory H2 database, and automatic CSV data seeding.
 */
@SpringBootApplication
public class CropDiseaseAdvisoryApplication {

    public static void main(String[] args) {
        SpringApplication.run(CropDiseaseAdvisoryApplication.class, args);
    }
}
