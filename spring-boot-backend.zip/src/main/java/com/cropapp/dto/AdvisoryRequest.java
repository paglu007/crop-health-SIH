package com.cropapp.dto;

import jakarta.validation.constraints.DecimalMax;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

/**
 * Incoming request payload for crop disease risk advisory calculation.
 */
public class AdvisoryRequest {

    @NotBlank(message = "Crop name is required (e.g., 'Tomato', 'Wheat')")
    private String crop;

    @NotBlank(message = "Disease name is required (e.g., 'Early Blight', 'Leaf Rust')")
    private String diseaseName;

    @NotNull(message = "CV Confidence score is required")
    @DecimalMin(value = "0.0", message = "cvConfidence must be >= 0.0")
    @DecimalMax(value = "1.0", message = "cvConfidence must be <= 1.0")
    private Double cvConfidence;

    @NotNull(message = "Weather risk score is required")
    @DecimalMin(value = "0.0", message = "weatherRiskScore must be >= 0.0")
    @DecimalMax(value = "1.0", message = "weatherRiskScore must be <= 1.0")
    private Double weatherRiskScore;

    public AdvisoryRequest() {
    }

    public AdvisoryRequest(String crop, String diseaseName, Double cvConfidence, Double weatherRiskScore) {
        this.crop = crop;
        this.diseaseName = diseaseName;
        this.cvConfidence = cvConfidence;
        this.weatherRiskScore = weatherRiskScore;
    }

    public String getCrop() {
        return crop;
    }

    public void setCrop(String crop) {
        this.crop = crop;
    }

    public String getDiseaseName() {
        return diseaseName;
    }

    public void setDiseaseName(String diseaseName) {
        this.diseaseName = diseaseName;
    }

    public Double getCvConfidence() {
        return cvConfidence;
    }

    public void setCvConfidence(Double cvConfidence) {
        this.cvConfidence = cvConfidence;
    }

    public Double getWeatherRiskScore() {
        return weatherRiskScore;
    }

    public void setWeatherRiskScore(Double weatherRiskScore) {
        this.weatherRiskScore = weatherRiskScore;
    }
}
