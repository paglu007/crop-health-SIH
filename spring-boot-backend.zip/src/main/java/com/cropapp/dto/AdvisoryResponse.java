package com.cropapp.dto;

import com.cropapp.risk.RiskLevel;

/**
 * Complete Advisory Response DTO containing all 12 agronomic, symptom, condition,
 * and treatment fields, plus calculated risk scores and expert advisory.
 */
public class AdvisoryResponse {

    private String crop;
    private String diseaseName;
    private String pathogenType;
    private String symptoms;
    private String favorableConditions;
    private RiskLevel riskLevel;
    private Double finalRiskScore;
    private String riskAdvisory;
    private String preventiveMeasures;
    private String organicTreatment;
    private String chemicalTreatment;
    private String expertAdvisory;
    private boolean recordFound;

    public AdvisoryResponse() {
    }

    public AdvisoryResponse(String crop, String diseaseName, String pathogenType, String symptoms,
                            String favorableConditions, RiskLevel riskLevel, Double finalRiskScore,
                            String riskAdvisory, String preventiveMeasures, String organicTreatment,
                            String chemicalTreatment, String expertAdvisory, boolean recordFound) {
        this.crop = crop;
        this.diseaseName = diseaseName;
        this.pathogenType = pathogenType;
        this.symptoms = symptoms;
        this.favorableConditions = favorableConditions;
        this.riskLevel = riskLevel;
        this.finalRiskScore = finalRiskScore;
        this.riskAdvisory = riskAdvisory;
        this.preventiveMeasures = preventiveMeasures;
        this.organicTreatment = organicTreatment;
        this.chemicalTreatment = chemicalTreatment;
        this.expertAdvisory = expertAdvisory;
        this.recordFound = recordFound;
    }

    // Getters and Setters

    public String getCrop() {
        return crop;
    }

    public void setCrop(String crop) {
        this.crop = crop;
    }

    public String getDiseaseName() {
        return diseaseName;
    }

    public void setDiseaseName(String diseaseName) {
        this.diseaseName = diseaseName;
    }

    public String getPathogenType() {
        return pathogenType;
    }

    public void setPathogenType(String pathogenType) {
        this.pathogenType = pathogenType;
    }

    public String getSymptoms() {
        return symptoms;
    }

    public void setSymptoms(String symptoms) {
        this.symptoms = symptoms;
    }

    public String getFavorableConditions() {
        return favorableConditions;
    }

    public void setFavorableConditions(String favorableConditions) {
        this.favorableConditions = favorableConditions;
    }

    public RiskLevel getRiskLevel() {
        return riskLevel;
    }

    public void setRiskLevel(RiskLevel riskLevel) {
        this.riskLevel = riskLevel;
    }

    public Double getFinalRiskScore() {
        return finalRiskScore;
    }

    public void setFinalRiskScore(Double finalRiskScore) {
        this.finalRiskScore = finalRiskScore;
    }

    public String getRiskAdvisory() {
        return riskAdvisory;
    }

    public void setRiskAdvisory(String riskAdvisory) {
        this.riskAdvisory = riskAdvisory;
    }

    public String getPreventiveMeasures() {
        return preventiveMeasures;
    }

    public void setPreventiveMeasures(String preventiveMeasures) {
        this.preventiveMeasures = preventiveMeasures;
    }

    public String getOrganicTreatment() {
        return organicTreatment;
    }

    public void setOrganicTreatment(String organicTreatment) {
        this.organicTreatment = organicTreatment;
    }

    public String getChemicalTreatment() {
        return chemicalTreatment;
    }

    public void setChemicalTreatment(String chemicalTreatment) {
        this.chemicalTreatment = chemicalTreatment;
    }

    public String getExpertAdvisory() {
        return expertAdvisory;
    }

    public void setExpertAdvisory(String expertAdvisory) {
        this.expertAdvisory = expertAdvisory;
    }

    public boolean isRecordFound() {
        return recordFound;
    }

    public void setRecordFound(boolean recordFound) {
        this.recordFound = recordFound;
    }
}
