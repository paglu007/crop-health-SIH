package com.cropapp.repository;

import com.cropapp.advisory.DiseaseAdvisory;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * Spring Data JPA Repository for querying DiseaseAdvisory records.
 * Provides case-insensitive lookup by crop and disease name, plus pathogen category filtering.
 */
@Repository
public interface DiseaseAdvisoryRepository extends JpaRepository<DiseaseAdvisory, Long> {

    /**
     * Finds a disease advisory record by crop name and disease name, ignoring case differences.
     *
     * @param crop        the name of the crop (e.g., "Tomato", "Wheat")
     * @param diseaseName the name of the disease (e.g., "Early Blight", "Blast")
     * @return an Optional containing the matching DiseaseAdvisory, or empty if not found
     */
    Optional<DiseaseAdvisory> findByCropIgnoreCaseAndDiseaseNameIgnoreCase(String crop, String diseaseName);

    /**
     * Finds all advisory records belonging to a given pathogen type.
     * Useful for agentic LLM agents to provide general pathogen-type management context.
     *
     * @param pathogenType one of: fungal_blight, fungal_rust, fungal_smut, bacterial, viral, nematode, phytoplasma, nutrient_disorder
     * @return a List of matching DiseaseAdvisory entities
     */
    List<DiseaseAdvisory> findByPathogenType(String pathogenType);

    /**
     * Finds all distinct crop names registered in the dataset.
     *
     * @return a list of crop names
     */
    List<DiseaseAdvisory> findByCropIgnoreCase(String crop);
}
