package com.cropapp.config;

import com.cropapp.advisory.DiseaseAdvisory;
import com.cropapp.repository.DiseaseAdvisoryRepository;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.stereotype.Component;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/**
 * Startup CommandLineRunner that parses the plant_disease_advisory_dataset.csv file
 * using Apache Commons CSV.
 *
 * CRITICAL ARCHITECTURAL NOTE:
 * Several fields in this dataset (especially 'symptoms', 'favorable_conditions',
 * 'high_risk_advisory', and 'chemical_treatment') contain internal commas enclosed in quotes.
 * A naive String.split(",") will corrupt the column alignment.
 * Apache Commons CSV correctly handles standard RFC 4180 quotation, multiline text,
 * and internal commas.
 */
@Component
public class CsvDataLoader implements CommandLineRunner {

    private static final Logger log = LoggerFactory.getLogger(CsvDataLoader.class);

    private final DiseaseAdvisoryRepository repository;
    private final ResourceLoader resourceLoader;

    @Value("${app.dataset.path:plant_disease_advisory_dataset.csv}")
    private String datasetPath;

    public CsvDataLoader(DiseaseAdvisoryRepository repository, ResourceLoader resourceLoader) {
        this.repository = repository;
        this.resourceLoader = resourceLoader;
    }

    @Override
    public void run(String... args) throws Exception {
        log.info("Beginning startup CSV data seeding from: {}", datasetPath);

        Resource resource = resourceLoader.getResource("classpath:" + datasetPath);
        if (!resource.exists()) {
            log.warn("Dataset resource classpath:{} not found. Attempting file: system fallback.", datasetPath);
            resource = resourceLoader.getResource("file:" + datasetPath);
        }

        if (!resource.exists()) {
            log.error("CRITICAL: plant_disease_advisory_dataset.csv could not be located! Skipping data load.");
            return;
        }

        // Configure Apache Commons CSV parser to skip header row and trim field whitespace
        CSVFormat csvFormat = CSVFormat.DEFAULT.builder()
                .setHeader()
                .setSkipHeaderRecord(true)
                .setIgnoreHeaderCase(true)
                .setTrim(true)
                .build();

        List<DiseaseAdvisory> recordsToSave = new ArrayList<>();

        try (BufferedReader reader = new BufferedReader(
                new InputStreamReader(resource.getInputStream(), StandardCharsets.UTF_8));
             CSVParser csvParser = new CSVParser(reader, csvFormat)) {

            for (CSVRecord record : csvParser) {
                try {
                    Long diseaseId = Long.parseLong(record.get("disease_id"));
                    String crop = record.get("crop");
                    String diseaseName = record.get("disease_name");
                    String pathogenType = record.get("pathogen_type");
                    String symptoms = record.get("symptoms");
                    String favorableConditions = record.get("favorable_conditions");
                    String lowRiskAdvisory = record.get("low_risk_advisory");
                    String mediumRiskAdvisory = record.get("medium_risk_advisory");
                    String highRiskAdvisory = record.get("high_risk_advisory");
                    String expertAdvisory = record.get("expert_advisory");
                    String preventiveMeasures = record.get("preventive_measures");
                    String organicTreatment = record.get("organic_treatment");
                    String chemicalTreatment = record.get("chemical_treatment");

                    DiseaseAdvisory advisory = new DiseaseAdvisory(
                            diseaseId,
                            crop,
                            diseaseName,
                            pathogenType,
                            symptoms,
                            favorableConditions,
                            lowRiskAdvisory,
                            mediumRiskAdvisory,
                            highRiskAdvisory,
                            expertAdvisory,
                            preventiveMeasures,
                            organicTreatment,
                            chemicalTreatment
                    );

                    recordsToSave.add(advisory);
                } catch (Exception ex) {
                    log.error("Error parsing row #{} (disease_id={}): {}",
                            record.getRecordNumber(), record.isSet("disease_id") ? record.get("disease_id") : "N/A", ex.getMessage());
                }
            }

            repository.saveAll(recordsToSave);
            log.info("Successfully loaded and indexed {} DiseaseAdvisory records into database.", repository.count());

        } catch (Exception e) {
            log.error("Failed to parse and load CSV dataset: {}", e.getMessage(), e);
            throw e;
        }
    }
}
