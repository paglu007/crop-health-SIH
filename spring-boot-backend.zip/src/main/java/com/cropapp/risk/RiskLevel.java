package com.cropapp.risk;

/**
 * Enumeration representing risk tiers for crop disease outbreak.
 * - LOW: finalRisk &lt; 0.4
 * - MEDIUM: finalRisk between 0.4 and 0.7 (inclusive)
 * - HIGH: finalRisk &gt; 0.7
 */
public enum RiskLevel {
    LOW,
    MEDIUM,
    HIGH;

    /**
     * Determines the risk level from the calculated final composite risk score.
     *
     * @param finalRisk composite score calculated from CV confidence and weather risk
     * @return LOW if score &lt; 0.4, MEDIUM if score is 0.4 to 0.7, HIGH if score &gt; 0.7
     */
    public static RiskLevel fromScore(double finalRisk) {
        if (finalRisk < 0.4) {
            return LOW;
        } else if (finalRisk <= 0.7) {
            return MEDIUM;
        } else {
            return HIGH;
        }
    }
}
