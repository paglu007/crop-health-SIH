package com.cropapp.risk;

import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;

/**
 * Service responsible for computing composite disease outbreak risk scores.
 * Formula: finalRisk = 0.6 * cvConfidence + 0.4 * weatherRiskScore
 * Thresholds:
 *   - LOW:    finalRisk &lt; 0.4
 *   - MEDIUM: finalRisk in [0.4, 0.7]
 *   - HIGH:   finalRisk &gt; 0.7
 */
@Service
public class RiskCalculator {

    private static final double CV_WEIGHT = 0.6;
    private static final double WEATHER_WEIGHT = 0.4;

    /**
     * Calculates the weighted composite risk score and maps it to a RiskLevel tier.
     *
     * @param cvConfidence      confidence score from computer vision leaf disease model (0.0 to 1.0)
     * @param weatherRiskScore  risk index derived from temperature, humidity, and rainfall (0.0 to 1.0)
     * @return RiskResult containing input scores, rounded final composite score, and determined RiskLevel
     * @throws IllegalArgumentException if scores are outside the [0.0, 1.0] interval
     */
    public RiskResult calculate(double cvConfidence, double weatherRiskScore) {
        if (cvConfidence < 0.0 || cvConfidence > 1.0) {
            throw new IllegalArgumentException("cvConfidence must be between 0.0 and 1.0. Given: " + cvConfidence);
        }
        if (weatherRiskScore < 0.0 || weatherRiskScore > 1.0) {
            throw new IllegalArgumentException("weatherRiskScore must be between 0.0 and 1.0. Given: " + weatherRiskScore);
        }

        double rawFinalRisk = (CV_WEIGHT * cvConfidence) + (WEATHER_WEIGHT * weatherRiskScore);
        
        // Round to 4 decimal places for clean representation
        double finalRisk = BigDecimal.valueOf(rawFinalRisk)
                .setScale(4, RoundingMode.HALF_UP)
                .doubleValue();

        RiskLevel level = RiskLevel.fromScore(finalRisk);

        return new RiskResult(cvConfidence, weatherRiskScore, finalRisk, level);
    }
}
