package com.cropapp.risk;

/**
 * Encapsulates the output of the multi-factor risk calculation.
 */
public class RiskResult {

    private final double cvConfidence;
    private final double weatherRiskScore;
    private final double finalRiskScore;
    private final RiskLevel riskLevel;

    public RiskResult(double cvConfidence, double weatherRiskScore, double finalRiskScore, RiskLevel riskLevel) {
        this.cvConfidence = cvConfidence;
        this.weatherRiskScore = weatherRiskScore;
        this.finalRiskScore = finalRiskScore;
        this.riskLevel = riskLevel;
    }

    public double getCvConfidence() {
        return cvConfidence;
    }

    public double getWeatherRiskScore() {
        return weatherRiskScore;
    }

    public double getFinalRiskScore() {
        return finalRiskScore;
    }

    public RiskLevel getRiskLevel() {
        return riskLevel;
    }

    @Override
    public String toString() {
        return "RiskResult{" +
                "cvConfidence=" + cvConfidence +
                ", weatherRiskScore=" + weatherRiskScore +
                ", finalRiskScore=" + finalRiskScore +
                ", riskLevel=" + riskLevel +
                '}';
    }
}
