package com.cropapp.advisory;

import com.cropapp.dto.AdvisoryRequest;
import com.cropapp.dto.AdvisoryResponse;
import com.cropapp.repository.DiseaseAdvisoryRepository;
import com.cropapp.risk.RiskCalculator;
import com.cropapp.risk.RiskLevel;
import com.cropapp.risk.RiskResult;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;

/**
 * End-to-end integration test verifying:
 * 1. Startup CSV loading of the 143 plant disease advisory records.
 * 2. Repository case-insensitive lookup for Tomato + Early Blight.
 * 3. Accurate risk calculation: finalRisk = 0.6 * CV + 0.4 * Weather.
 * 4. Full population of all 12 agronomic fields in AdvisoryResponse.
 * 5. Safe, non-throwing fallback handling for unrecorded diseases.
 */
@SpringBootTest
public class DiseaseAdvisoryIntegrationTest {

    @Autowired
    private DiseaseAdvisoryRepository repository;

    @Autowired
    private AdvisoryService advisoryService;

    @Autowired
    private RiskCalculator riskCalculator;

    @Test
    @DisplayName("Verify CSV dataset loaded into database on startup")
    public void testDatabaseContainsLoadedRecords() {
        long count = repository.count();
        assertTrue(count >= 140, "Database should have loaded all 143 records from CSV, found: " + count);
    }

    @Test
    @DisplayName("Verify RiskCalculator computes final risk and assigns HIGH risk level")
    public void testRiskCalculator() {
        // Given cvConfidence = 0.82, weatherRiskScore = 0.75
        // Expected: finalRisk = 0.6 * 0.82 + 0.4 * 0.75 = 0.492 + 0.300 = 0.792 (> 0.7 -> HIGH)
        RiskResult result = riskCalculator.calculate(0.82, 0.75);

        assertNotNull(result);
        assertEquals(0.792, result.getFinalRiskScore(), 0.001);
        assertEquals(RiskLevel.HIGH, result.getRiskLevel());
    }

    @Test
    @DisplayName("Verify Repository lookup and full AdvisoryResponse population for Tomato + Early Blight")
    public void testTomatoEarlyBlightAdvisoryAllFieldsPopulated() {
        // 1. Direct Repository query test
        Optional<DiseaseAdvisory> recordOpt = repository.findByCropIgnoreCaseAndDiseaseNameIgnoreCase("Tomato", "Early Blight");
        assertTrue(recordOpt.isPresent(), "Record for Tomato + Early Blight must exist in dataset");

        DiseaseAdvisory entity = recordOpt.get();
        assertEquals("Tomato", entity.getCrop());
        assertEquals("Early Blight", entity.getDiseaseName());
        assertEquals("fungal_blight", entity.getPathogenType());
        assertTrue(entity.getSymptoms().contains("Concentric dark spots"));

        // 2. End-to-end Advisory Service test with cvConfidence=0.82 and weatherRiskScore=0.75
        AdvisoryRequest request = new AdvisoryRequest("Tomato", "Early Blight", 0.82, 0.75);
        AdvisoryResponse response = advisoryService.processAdvisory(request);

        assertNotNull(response);
        assertTrue(response.isRecordFound(), "Record should be found in dataset");
        assertEquals("Tomato", response.getCrop());
        assertEquals("Early Blight", response.getDiseaseName());
        assertEquals("fungal_blight", response.getPathogenType());
        assertEquals(RiskLevel.HIGH, response.getRiskLevel());
        assertEquals(0.792, response.getFinalRiskScore(), 0.001);

        // Assert all free-text fields are correctly populated and not truncated
        assertNotNull(response.getSymptoms(), "symptoms must not be null");
        assertNotNull(response.getFavorableConditions(), "favorableConditions must not be null");
        assertNotNull(response.getRiskAdvisory(), "riskAdvisory must not be null");
        assertNotNull(response.getPreventiveMeasures(), "preventiveMeasures must not be null");
        assertNotNull(response.getOrganicTreatment(), "organicTreatment must not be null");
        assertNotNull(response.getChemicalTreatment(), "chemicalTreatment must not be null");
        assertNotNull(response.getExpertAdvisory(), "expertAdvisory must be included");

        // Assert that for HIGH risk, the high_risk_advisory text was chosen
        assertEquals(entity.getHighRiskAdvisory(), response.getRiskAdvisory());
        assertTrue(response.getRiskAdvisory().contains("Conditions are strongly favorable for rapid spread"));
    }

    @Test
    @DisplayName("Verify graceful fallback response when crop or disease is unknown without throwing exception")
    public void testFallbackAdvisoryForUnknownDisease() {
        AdvisoryRequest request = new AdvisoryRequest("Avocado", "Unknown Blight", 0.5, 0.5);
        AdvisoryResponse response = assertDoesNotThrow(() -> advisoryService.processAdvisory(request));

        assertNotNull(response);
        assertFalse(response.isRecordFound(), "Record should be marked as not found");
        assertEquals("Avocado", response.getCrop());
        assertEquals("Unknown Blight", response.getDiseaseName());
        assertEquals(RiskLevel.MEDIUM, response.getRiskLevel());
        assertTrue(response.getRiskAdvisory().contains("Krishi Vigyan Kendra") || response.getRiskAdvisory().contains("extension"));
        assertTrue(response.getExpertAdvisory().contains("Kisan Call Center") || response.getExpertAdvisory().contains("extension"));
    }
}
